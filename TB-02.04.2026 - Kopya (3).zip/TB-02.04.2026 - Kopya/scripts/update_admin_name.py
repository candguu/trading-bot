import sqlite3
import os

DB_PATH = "tb_database.db"
conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row

# Update admin name
conn.execute("UPDATE users SET first_name=?, last_name=? WHERE email=?", 
             ("Admin", "Can", "admin@tbot.com"))
conn.commit()

# Verify the change
admin = conn.execute("SELECT first_name, last_name, email FROM users WHERE email=?", 
                     ("admin@tbot.com",)).fetchone()
if admin:
    print(f"Admin güncellendi: {admin['first_name']} {admin['last_name']} ({admin['email']})")
else:
    print("Admin bulunamadı")

conn.close()
