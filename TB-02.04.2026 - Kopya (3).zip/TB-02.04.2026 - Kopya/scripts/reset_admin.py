import sqlite3
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.security import _hash_password

DB_PATH = "tb_database.db"
conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row

# Check if admin exists
admin = conn.execute("SELECT id, email, role FROM users WHERE email=?", ("admin@tbot.com",)).fetchone()
if admin:
    print(f"Admin found: id={admin['id']}, email={admin['email']}, role={admin['role']}")
    # Reset password to 12345
    new_hash = _hash_password("12345")
    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (new_hash, admin['id']))
    conn.commit()
    print("Admin password reset to: 12345")
else:
    print("Admin not found - will be created on next server start")

conn.close()
