"""
Kullanıcı şifresini sıfırla
"""
import sqlite3
import hashlib

def hash_password(password: str) -> str:
    """core/security.py ile aynı yöntem"""
    salt = hashlib.sha256(b'fixed_salt_for_reset').hexdigest()  # Sabit salt test için
    hashed = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260000)
    return f"{salt}${hashed.hex()}"

# Kullanıcı bilgileri
email = "npcan3@gmail.com"
new_password = "12345678"  # Yeni şifre

# Database'e bağlan
conn = sqlite3.connect('tb_database.db')
cursor = conn.cursor()

# Kullanıcıyı bul
cursor.execute('SELECT id, email, first_name FROM users WHERE email=?', (email,))
user = cursor.fetchone()

if not user:
    print(f"❌ Kullanıcı bulunamadı: {email}")
    conn.close()
    exit(1)

print(f"\n✅ Kullanıcı bulundu:")
print(f"ID: {user[0]}")
print(f"Email: {user[1]}")
print(f"İsim: {user[2]}")

# Yeni şifre hash'i oluştur
password_hash = hash_password(new_password)

# Şifreyi güncelle
cursor.execute('UPDATE users SET password_hash=? WHERE id=?', (password_hash, user[0]))
conn.commit()

print(f"\n✅ Şifre güncellendi!")
print(f"Yeni şifre: {new_password}")
print(f"\nŞimdi giriş yapabilirsiniz:")
print(f"Email: {email}")
print(f"Şifre: {new_password}")

conn.close()
