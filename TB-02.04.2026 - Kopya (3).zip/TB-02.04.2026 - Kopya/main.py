"""
TB Trading Bot - Ana Backend Sunucu
=====================================
Kurulum:
    pip install flask flask-cors requests bcrypt pyjwt python-dotenv

Çalıştır:
    python main.py

Tarayıcı: http://localhost:5000
"""

import os
from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv
from core.database import init_db, close_db

# Ortam değişkenlerini yükle
load_dotenv()

# Uygulamayı Oluştur
app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

# CORS Ayarları
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "http://localhost:5000").split(",")
CORS(app, supports_credentials=True, origins=ALLOWED_ORIGINS)

# Blueprint'leri İçe Aktar ve Kaydet
from routes.auth_routes import auth_bp
from routes.bot_routes import bot_bp
from routes.user_routes import user_bp
from routes.market_routes import market_bp
from routes.page_routes import page_bp
from routes.chart_routes import chart_bp
from routes.ott_routes import ott_bp
from routes.trading_routes import trading_bp
from routes.binance_routes import binance_bp

app.register_blueprint(page_bp)
app.register_blueprint(auth_bp, url_prefix="/api/auth")
app.register_blueprint(bot_bp, url_prefix="/api/bot")
app.register_blueprint(user_bp, url_prefix="/api/user")
app.register_blueprint(market_bp, url_prefix="/api/market")
app.register_blueprint(chart_bp, url_prefix="/api/chart")
app.register_blueprint(ott_bp, url_prefix="/api/ott")
app.register_blueprint(trading_bp, url_prefix="/api/trading")
app.register_blueprint(binance_bp, url_prefix="/api/binance")

# Uygulama Kapanırken DB Bağlantısını Kapat
app.teardown_appcontext(close_db)

if __name__ == "__main__":
    PORT = int(os.getenv("PORT", 5000))
    DEBUG = os.getenv("DEBUG", "false").lower() == "true"
    
    # DB'yi başlat
    with app.app_context():
        init_db(app)
        
    # Start background bot daemon
    from core.bot_daemon import bot_daemon
    bot_daemon.start()
        
    print(f"\n[TB] Sunucu baslatiliyor ({'DEBUG' if DEBUG else 'PROD'}) ...")
    print(f"[TB] http://localhost:{PORT}")
    try:
        app.run(host="0.0.0.0", port=PORT, debug=DEBUG, use_reloader=False)
    finally:
        bot_daemon.stop()

