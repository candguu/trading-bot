import sqlite3
import os
from flask import g
from datetime import datetime, timezone

DB_PATH = os.getenv("DB_PATH", os.path.join(os.path.dirname(os.path.dirname(__file__)), "tb_database.db"))

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db_dir = os.path.dirname(DB_PATH)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
        db = g._database = sqlite3.connect(DB_PATH, check_same_thread=False)
        db.row_factory = sqlite3.Row
    return db

def close_db(exc=None):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def init_db(app):
    db_dir = os.path.dirname(DB_PATH)
    if db_dir and not os.path.exists(db_dir):
        os.makedirs(db_dir, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name    TEXT    NOT NULL,
            last_name     TEXT    NOT NULL,
            email         TEXT    NOT NULL UNIQUE,
            phone         TEXT,
            password_hash TEXT    NOT NULL,
            role          TEXT    NOT NULL DEFAULT 'user',
            is_active     INTEGER NOT NULL DEFAULT 1,
            is_verified   INTEGER NOT NULL DEFAULT 0,
            country       TEXT    DEFAULT 'TR',
            language      TEXT    DEFAULT 'tr',
            created_at    TEXT    NOT NULL,
            last_login    TEXT
        )
    """)

    # Migration: mevcut DB'ye is_verified ekle
    try:
        c.execute("ALTER TABLE users ADD COLUMN is_verified INTEGER NOT NULL DEFAULT 0")
        conn.commit()
    except Exception:
        pass
    
    # Migration: mevcut DB'ye country ekle
    try:
        c.execute("ALTER TABLE users ADD COLUMN country TEXT DEFAULT 'TR'")
        conn.commit()
    except Exception:
        pass
    
    # Migration: mevcut DB'ye language ekle
    try:
        c.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'tr'")
        conn.commit()
    except Exception:
        pass

    c.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            token      TEXT    NOT NULL,
            created_at TEXT    NOT NULL,
            expires_at TEXT    NOT NULL,
            revoked    INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS bot_configs (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id          INTEGER NOT NULL UNIQUE,
            exchange         TEXT    DEFAULT 'binance',
            api_key          TEXT,
            api_secret       TEXT,
            api_key_hint     TEXT,
            strategy         TEXT    DEFAULT 'hybrid',
            leverage         INTEGER DEFAULT 3,
            risk_per_trade   REAL    DEFAULT 2.0,
            max_positions    INTEGER DEFAULT 5,
            stop_loss        REAL    DEFAULT 3.0,
            take_profit      REAL    DEFAULT 6.0,
            timeframe        TEXT    DEFAULT '5m',
            is_active        INTEGER DEFAULT 0,
            updated_at       TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Migration: Add api_key and api_secret columns if they don't exist
    try:
        c.execute("ALTER TABLE bot_configs ADD COLUMN api_key TEXT")
        conn.commit()
    except Exception:
        pass
    
    try:
        c.execute("ALTER TABLE bot_configs ADD COLUMN api_secret TEXT")
        conn.commit()
    except Exception:
        pass
    
    try:
        c.execute("ALTER TABLE bot_configs ADD COLUMN api_key_hint TEXT")
        conn.commit()
    except Exception:
        pass
    
    try:
        c.execute("ALTER TABLE bot_configs ADD COLUMN label TEXT")
        conn.commit()
    except Exception:
        pass

    c.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            type       TEXT    NOT NULL,
            title      TEXT    NOT NULL,
            message    TEXT    NOT NULL,
            is_read    INTEGER NOT NULL DEFAULT 0,
            created_at TEXT    NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # E-posta doğrulama tokenları
    c.execute("""
        CREATE TABLE IF NOT EXISTS email_verifications (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            token      TEXT    NOT NULL UNIQUE,
            created_at TEXT    NOT NULL,
            expires_at TEXT    NOT NULL,
            used       INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # Şifre sıfırlama kodları
    c.execute("""
        CREATE TABLE IF NOT EXISTS password_resets (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            code       TEXT    NOT NULL,
            created_at TEXT    NOT NULL,
            expires_at TEXT    NOT NULL,
            used       INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # Şifre değiştirme kodları (giriş yapmış kullanıcılar için)
    c.execute("""
        CREATE TABLE IF NOT EXISTS password_reset_codes (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            code       TEXT    NOT NULL,
            expires_at TEXT    NOT NULL,
            created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    # Binance API anahtarları (şifreli)
    c.execute("""
        CREATE TABLE IF NOT EXISTS api_keys (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id        INTEGER NOT NULL UNIQUE,
            api_key_enc    TEXT    NOT NULL,
            api_secret_enc TEXT    NOT NULL,
            is_testnet     INTEGER NOT NULL DEFAULT 1,
            is_valid       INTEGER NOT NULL DEFAULT 0,
            created_at     TEXT    NOT NULL,
            updated_at     TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Çoklu API desteği için yeni tablo
    c.execute("""
        CREATE TABLE IF NOT EXISTS user_api_keys (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id        INTEGER NOT NULL,
            api_key_enc    TEXT    NOT NULL,
            api_secret_enc TEXT    NOT NULL,
            label          TEXT,
            is_testnet     INTEGER NOT NULL DEFAULT 1,
            is_active      INTEGER NOT NULL DEFAULT 0,
            is_valid       INTEGER NOT NULL DEFAULT 0,
            created_at     TEXT    NOT NULL,
            updated_at     TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Index for faster queries
    c.execute("""
        CREATE INDEX IF NOT EXISTS idx_user_api_keys_user_id 
        ON user_api_keys(user_id)
    """)
    
    c.execute("""
        CREATE INDEX IF NOT EXISTS idx_user_api_keys_active 
        ON user_api_keys(user_id, is_active)
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS bot_logs (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            symbol     TEXT    NOT NULL,
            signal     TEXT    NOT NULL,
            price      REAL    NOT NULL,
            source     TEXT    NOT NULL,
            created_at TEXT    NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    conn.commit()
    _create_admin_if_missing(conn)
    conn.close()
    print("[DB] Veritabani hazir ->", DB_PATH)

def _create_admin_if_missing(conn):
    from core.security import _hash_password
    admin_email    = os.getenv("ADMIN_EMAIL", "admin@tbot.com")
    admin_password = os.getenv("ADMIN_PASSWORD")
    if not admin_password:
        print("[DB] UYARI: ADMIN_PASSWORD .env dosyasinda tanimli degil, admin hesabi atlaniyor.")
        return
    c = conn.cursor()
    c.execute("SELECT id FROM users WHERE email = ?", (admin_email,))
    if c.fetchone():
        # Admin zaten var — API key'leri güncelle
        _setup_admin_api_keys(conn)
        return
    pw_hash = _hash_password(admin_password)
    now = datetime.now(timezone.utc).isoformat()
    c.execute("""
        INSERT INTO users (first_name, last_name, email, phone, password_hash, role, is_verified, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, ("Admin", "TB", admin_email, "", pw_hash, "admin", 1, now))
    uid = c.lastrowid
    c.execute("INSERT INTO bot_configs (user_id, strategy, leverage, risk_per_trade, is_active, updated_at) VALUES (?,?,?,?,?,?)",
              (uid, "hybrid", 3, 2.0, 1, now))
    c.execute("INSERT INTO notifications (user_id, type, title, message, created_at) VALUES (?,?,?,?,?)",
              (uid, "welcome", "TB'ye Hos Geldiniz!", "Hesabiniz olusturuldu. Binance API anahtarinizi baglayin.", now))
    conn.commit()
    print(f"[DB] Admin hesabi olusturuldu -> {admin_email}")
    _setup_admin_api_keys(conn)

def _setup_admin_api_keys(conn):
    """Admin hesabına .env'deki Binance API key'lerini otomatik ekle."""
    api_key = os.getenv("BINANCE_API_KEY", "").strip()
    api_secret = os.getenv("BINANCE_API_SECRET", "").strip()
    if not api_key or not api_secret:
        return

    admin_email = os.getenv("ADMIN_EMAIL", "admin@tbot.com")
    c = conn.cursor()
    c.execute("SELECT id FROM users WHERE email = ?", (admin_email,))
    row = c.fetchone()
    if not row:
        return
    uid = row[0]
    now = datetime.now(timezone.utc).isoformat()

    # bot_configs tablosuna API anahtarlarını ekle (binance_routes için)
    try:
        c.execute("SELECT id FROM bot_configs WHERE user_id=?", (uid,))
        if c.fetchone():
            c.execute("""
                UPDATE bot_configs 
                SET api_key=?, api_secret=?, api_key_hint=?, updated_at=?
                WHERE user_id=?
            """, (api_key, api_secret, api_key[:8] + "...", now, uid))
        else:
            c.execute("""
                INSERT INTO bot_configs (user_id, api_key, api_secret, api_key_hint, strategy, leverage, risk_per_trade, is_active, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (uid, api_key, api_secret, api_key[:8] + "...", "hybrid", 3, 2.0, 1, now))
    except Exception as e:
        print(f"[DB] Admin bot_configs API key setup hatasi: {e}")

    # api_keys tablosuna şifreli API anahtarlarını ekle (trading_routes için)
    try:
        from core.crypto_utils import encrypt_value
        api_key_enc = encrypt_value(api_key)
        api_secret_enc = encrypt_value(api_secret)
        
        c.execute("SELECT id FROM api_keys WHERE user_id=?", (uid,))
        if c.fetchone():
            c.execute("""
                UPDATE api_keys 
                SET api_key_enc=?, api_secret_enc=?, is_valid=1, updated_at=?
                WHERE user_id=?
            """, (api_key_enc, api_secret_enc, now, uid))
        else:
            c.execute("""
                INSERT INTO api_keys (user_id, api_key_enc, api_secret_enc, is_testnet, is_valid, created_at, updated_at)
                VALUES (?, ?, ?, 1, 1, ?, ?)
            """, (uid, api_key_enc, api_secret_enc, now, now))
    except Exception as e:
        print(f"[DB] Admin api_keys setup hatasi: {e}")

    conn.commit()
    print("[DB] Admin API anahtarlari otomatik baglandi [OK]")
