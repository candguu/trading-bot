#!/usr/bin/env python3
"""
API Keys Database Migration Script
===================================
Bu script eksik kolonları ekler ve API key yapısını düzeltir.
"""

import sqlite3
import os

DB_PATH = os.getenv("DB_PATH", "tb_database.db")

def migrate_database():
    """Database'e eksik kolonları ekle"""
    print(f"[MIGRATION] Connecting to database: {DB_PATH}")
    
    if not os.path.exists(DB_PATH):
        print(f"[ERROR] Database file not found: {DB_PATH}")
        return False
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    migrations = [
        ("bot_configs", "api_key", "TEXT"),
        ("bot_configs", "api_secret", "TEXT"),
        ("bot_configs", "api_key_hint", "TEXT"),
        ("bot_configs", "label", "TEXT"),
        ("bot_configs", "is_active", "INTEGER DEFAULT 0"),
    ]
    
    for table, column, col_type in migrations:
        try:
            # Check if column exists
            c.execute(f"PRAGMA table_info({table})")
            columns = [row[1] for row in c.fetchall()]
            
            if column not in columns:
                print(f"[MIGRATION] Adding column {table}.{column}")
                c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type}")
                conn.commit()
                print(f"[SUCCESS] Added {table}.{column}")
            else:
                print(f"[SKIP] Column {table}.{column} already exists")
        except Exception as e:
            print(f"[ERROR] Failed to add {table}.{column}: {e}")
    
    # Create user_api_keys table if not exists
    try:
        c.execute("""
            CREATE TABLE IF NOT EXISTS user_api_keys (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        INTEGER NOT NULL,
                api_key_enc    TEXT    NOT NULL,
                api_secret_enc TEXT    NOT NULL,
                label          TEXT,
                is_testnet     INTEGER NOT NULL DEFAULT 1,
                is_active      INTEGER NOT NULL DEFAULT 0,
                is_valid       INTEGER NOT NULL DEFAULT 0,
                created_at     TEXT    NOT NULL,
                updated_at     TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)
        conn.commit()
        print("[SUCCESS] user_api_keys table created/verified")
    except Exception as e:
        print(f"[ERROR] Failed to create user_api_keys table: {e}")
    
    # Create indexes
    try:
        c.execute("""
            CREATE INDEX IF NOT EXISTS idx_user_api_keys_user_id 
            ON user_api_keys(user_id)
        """)
        c.execute("""
            CREATE INDEX IF NOT EXISTS idx_user_api_keys_active 
            ON user_api_keys(user_id, is_active)
        """)
        conn.commit()
        print("[SUCCESS] Indexes created/verified")
    except Exception as e:
        print(f"[ERROR] Failed to create indexes: {e}")
    
    # Create password_reset_codes table if not exists
    try:
        c.execute("""
            CREATE TABLE IF NOT EXISTS password_reset_codes (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER NOT NULL,
                code       TEXT    NOT NULL,
                expires_at TEXT    NOT NULL,
                created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        """)
        conn.commit()
        print("[SUCCESS] password_reset_codes table created/verified")
    except Exception as e:
        print(f"[ERROR] Failed to create password_reset_codes table: {e}")
    
    conn.close()
    print("[MIGRATION] Database migration completed!")
    return True

if __name__ == "__main__":
    migrate_database()
