import threading
import time

import requests
from flask import Blueprint, jsonify, request

market_bp = Blueprint("market", __name__)

COINGECKO_URL = "https://api.coingecko.com/api/v3"
COINPAPRIKA_URL = "https://api.coinpaprika.com/v1"
ALTERNATIVE_FNG_URL = "https://api.alternative.me/fng/"
CACHE_TTL = 60

_cache = {
    "top50": {"data": None, "ts": 0},
    "global": {"data": None, "ts": 0},
    "fear_greed": {"data": None, "ts": 0},
}
_cache_lock = threading.Lock()


def _get_cached(cache_key: str, now: float):
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and cached["data"] and (now - cached["ts"] < CACHE_TTL):
            return cached["data"]
    return None


def _set_cached(cache_key: str, data, now: float) -> None:
    with _cache_lock:
        _cache[cache_key] = {"data": data, "ts": now}


def _get_cache_fallback(cache_key: str):
    with _cache_lock:
        cached = _cache.get(cache_key)
        return cached["data"] if cached else None


def _normalize_coinpaprika_global(data: dict) -> dict:
    return {
        "data": {
            "active_cryptocurrencies": data.get("cryptocurrencies_number"),
            "markets": None,
            "total_market_cap": {"usd": data.get("market_cap_usd")},
            "total_volume": {"usd": data.get("volume_24h_usd")},
            "market_cap_percentage": {"btc": data.get("bitcoin_dominance_percentage")},
            "market_cap_change_percentage_24h_usd": data.get("market_cap_change_24h"),
            "updated_at": data.get("last_updated"),
        },
        "source": "coinpaprika",
    }


def _normalize_coinpaprika_ticker(ticker: dict) -> dict:
    usd = (ticker.get("quotes") or {}).get("USD") or {}
    return {
        "id": ticker.get("id"),
        "symbol": (ticker.get("symbol") or "").lower(),
        "name": ticker.get("name"),
        "image": None,
        "current_price": usd.get("price"),
        "market_cap": usd.get("market_cap"),
        "market_cap_rank": ticker.get("rank"),
        "fully_diluted_valuation": None,
        "total_volume": usd.get("volume_24h"),
        "high_24h": None,
        "low_24h": None,
        "price_change_24h": None,
        "price_change_percentage_24h": usd.get("percent_change_24h"),
        "market_cap_change_24h": None,
        "market_cap_change_percentage_24h": usd.get("market_cap_change_24h"),
        "circulating_supply": ticker.get("circulating_supply"),
        "total_supply": ticker.get("total_supply"),
        "max_supply": ticker.get("max_supply"),
        "ath": usd.get("ath_price"),
        "ath_change_percentage": usd.get("percent_from_price_ath"),
        "ath_date": usd.get("ath_date"),
        "roi": None,
        "last_updated": ticker.get("last_updated"),
        "sparkline_in_7d": None,
        "price_change_percentage_7d_in_currency": usd.get("percent_change_7d"),
    }


def _fetch_coinpaprika_tickers() -> list[dict]:
    now = time.time()
    cache_key = "coinpaprika_tickers"
    cached = _get_cached(cache_key, now)
    if cached:
        return cached

    response = requests.get(f"{COINPAPRIKA_URL}/tickers", params={"quotes": "USD"}, timeout=15)
    response.raise_for_status()
    tickers = response.json()
    _set_cached(cache_key, tickers, now)
    return tickers


def _fetch_coingecko_markets(page: int, per_page: int):
    response = requests.get(
        f"{COINGECKO_URL}/coins/markets",
        params={
            "vs_currency": "usd",
            "order": "market_cap_desc",
            "per_page": per_page,
            "page": page,
            "sparkline": False,
            "price_change_percentage": "7d",
        },
        timeout=10,
    )
    if response.status_code != 200:
        raise RuntimeError(f"CoinGecko API Error: {response.status_code}")
    return response.json()


def _fetch_coinpaprika_markets(page: int, per_page: int):
    tickers = _fetch_coinpaprika_tickers()
    start = max((page - 1) * per_page, 0)
    end = start + per_page
    return [_normalize_coinpaprika_ticker(ticker) for ticker in tickers[start:end]]


@market_bp.route("/top50", methods=["GET"])
def market_top50():
    now = time.time()
    cached = _get_cached("top50", now)
    if cached:
        return jsonify(cached)

    try:
        data = _fetch_coingecko_markets(page=1, per_page=50)
        _set_cached("top50", data, now)
        return jsonify(data)
    except Exception as error:
        print(f"[TOP50] CoinGecko failed, falling back to CoinPaprika: {error}")

    try:
        data = _fetch_coinpaprika_markets(page=1, per_page=50)
        _set_cached("top50", data, now)
        return jsonify(data)
    except Exception as error:
        print(f"[TOP50] CoinPaprika failed: {error}")

    cached = _get_cache_fallback("top50")
    if cached:
        return jsonify(cached)
    return jsonify({"error": "Market verisi alinamadi"}), 503


@market_bp.route("/global", methods=["GET"])
def market_global():
    now = time.time()
    cached = _get_cached("global", now)
    if cached:
        return jsonify(cached)

    try:
        response = requests.get(f"{COINGECKO_URL}/global", timeout=10)
        response.raise_for_status()
        data = response.json()
        _set_cached("global", data, now)
        return jsonify(data)
    except Exception as error:
        print(f"[GLOBAL] CoinGecko failed, falling back to CoinPaprika: {error}")

    try:
        response = requests.get(f"{COINPAPRIKA_URL}/global", timeout=10)
        response.raise_for_status()
        data = _normalize_coinpaprika_global(response.json())
        _set_cached("global", data, now)
        return jsonify(data)
    except Exception as error:
        print(f"[GLOBAL] CoinPaprika failed: {error}")

    cached = _get_cache_fallback("global")
    if cached:
        return jsonify(cached)
    return jsonify({"error": "Global data hatasi"}), 503


@market_bp.route("/binance-ticker", methods=["GET"])
def binance_ticker():
    now = time.time()
    cache_key = "binance_ticker"
    cached = _get_cached(cache_key, now)
    if cached:
        print(f"[BINANCE TICKER] Returning cached data ({len(cached)} tickers)")
        return jsonify(cached)

    try:
        url = "https://testnet.binancefuture.com/fapi/v1/ticker/24hr"
        print(f"[BINANCE TICKER] Fetching from: {url}")
        response = requests.get(url, timeout=10)
        print(f"[BINANCE TICKER] Response status: {response.status_code}")
        response.raise_for_status()
        data = response.json()
        print(f"[BINANCE TICKER] Received {len(data)} tickers")
        _set_cached(cache_key, data, now)
        return jsonify(data)
    except requests.exceptions.Timeout:
        print("[BINANCE TICKER] Timeout error")
    except Exception as error:
        print(f"[BINANCE TICKER] Exception: {error}")

    cached = _get_cache_fallback(cache_key)
    if cached:
        print("[BINANCE TICKER] Returning cached data after error")
        return jsonify(cached)
    return jsonify({"error": "Binance API timeout"}), 504


@market_bp.route("/coingecko-markets", methods=["GET"])
def coingecko_markets():
    page = int(request.args.get("page", 1))
    per_page = min(int(request.args.get("per_page", 250)), 250)

    cache_key = f"coingecko_markets_p{page}_{per_page}"
    now = time.time()
    cached = _get_cached(cache_key, now)
    if cached:
        print(f"[MARKETS] Returning cached data for page {page}")
        return jsonify(cached)

    try:
        print(f"[COINGECKO] Fetching page {page} from CoinGecko API...")
        data = _fetch_coingecko_markets(page=page, per_page=per_page)
        print(f"[COINGECKO] Received {len(data)} coins for page {page}")
        _set_cached(cache_key, data, now)
        return jsonify(data)
    except Exception as error:
        print(f"[COINGECKO] Failed, falling back to CoinPaprika: {error}")

    try:
        data = _fetch_coinpaprika_markets(page=page, per_page=per_page)
        print(f"[COINPAPRIKA] Returning {len(data)} coins for page {page}")
        _set_cached(cache_key, data, now)
        return jsonify(data)
    except Exception as error:
        print(f"[COINPAPRIKA] Failed: {error}")

    cached = _get_cache_fallback(cache_key)
    if cached:
        return jsonify(cached)
    return jsonify({"error": "Market data alinamadi"}), 503


@market_bp.route("/fear-greed", methods=["GET"])
def fear_greed():
    now = time.time()
    cached = _get_cached("fear_greed", now)
    if cached:
        return jsonify(cached)

    try:
        response = requests.get(ALTERNATIVE_FNG_URL, params={"limit": 1}, timeout=10)
        response.raise_for_status()
        data = response.json()
        _set_cached("fear_greed", data, now)
        return jsonify(data)
    except Exception as error:
        print(f"[FNG] Fetch failed: {error}")

    cached = _get_cache_fallback("fear_greed")
    if cached:
        return jsonify(cached)
    return jsonify({"error": "Fear & Greed verisi alinamadi"}), 503
