// Close position modal flow for the portfolio page.
console.log('[CLOSE POSITION MODAL] Script loaded');

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initClosePositionModal);
} else {
    initClosePositionModal();
}

function initClosePositionModal() {
    if (window.__closePositionModalInitialized) {
        return;
    }
    window.__closePositionModalInitialized = true;

    console.log('[CLOSE POSITION MODAL] Initializing...');

    document.body.addEventListener('click', function (e) {
        const btn = e.target.closest('.pf-close-btn');
        if (!btn) return;

        console.log('[CLOSE POSITION] Button clicked', btn);
        e.preventDefault();
        e.stopPropagation();

        const symbol = btn.getAttribute('data-symbol');
        const amount = parseFloat(btn.getAttribute('data-amount'));
        const side = btn.getAttribute('data-side');
        const positionSide = btn.getAttribute('data-position-side');

        console.log('[CLOSE POSITION] Data:', { symbol, amount, side, positionSide });

        if (symbol && !Number.isNaN(amount)) {
            closePosition(symbol, amount, side || 'Long', positionSide);
            return;
        }

        console.error('[CLOSE POSITION] Invalid data:', { symbol, amount, side, positionSide });
        notifyClosePosition('Gecersiz pozisyon verisi', 'error');
    }, true);

    console.log('[CLOSE POSITION MODAL] Event listener attached');
}

async function closePosition(symbol, positionAmt, side, positionSide) {
    console.log('[CLOSE POSITION] Function called with:', { symbol, positionAmt, side, positionSide });

    if (typeof AUTH === 'undefined' || !AUTH || !AUTH.token) {
        console.error('[CLOSE POSITION] AUTH not found');
        notifyClosePosition('Oturum bulunamadi. Lutfen tekrar giris yapin.', 'error');
        return;
    }

    if (typeof positionAmt === 'string') {
        positionAmt = parseFloat(positionAmt);
    }

    const selector = positionSide && (positionSide === 'LONG' || positionSide === 'SHORT')
        ? `.position-row[data-symbol="${symbol}"][data-position-side="${positionSide}"]`
        : `.position-row[data-symbol="${symbol}"]`;
    const row = document.querySelector(selector);

    let entryPrice = '--';
    let lastPrice = '--';
    let markPrice = '--';
    let liqPrice = '--';
    let margin = '--';
    let marginRatio = '--';
    let pnlText = '--';
    let roiText = '--';
    let leverage = '--';

    if (row) {
        const cells = Array.from(row.querySelectorAll('td'));
        if (cells.length >= 10) {
            const headerBits = cells[0]?.querySelectorAll('span');
            leverage = headerBits?.[2]?.textContent.trim() || '--';
            entryPrice = cells[2]?.querySelector('div')?.textContent.trim() || '--';
            lastPrice = cells[3]?.querySelector('div')?.textContent.trim() || '--';
            markPrice = cells[4]?.querySelector('div')?.textContent.trim() || '--';
            liqPrice = cells[5]?.querySelector('div')?.textContent.trim() || '--';
            margin = cells[6]?.querySelector('div')?.textContent.trim() || '--';
            marginRatio = cells[7]?.querySelector('div')?.textContent.trim() || '--';

            const pnlBlocks = cells[8]?.querySelectorAll('div');
            pnlText = pnlBlocks?.[0]?.textContent.trim() || '--';
            roiText = pnlBlocks?.[1]?.textContent.trim() || '--';
        }
    }

    showPortfolioClosePositionModal({
        symbol,
        positionAmt,
        side,
        positionSide: positionSide || (side === 'Long' ? 'LONG' : 'SHORT'),
        entryPrice,
        lastPrice,
        markPrice,
        liqPrice,
        margin,
        marginRatio,
        leverage,
        pnl: pnlText,
        roi: roiText
    });
}

function showPortfolioClosePositionModal(data) {
    console.log('[CLOSE POSITION] Showing modal with data:', data);
    ensurePortfolioUsesFuturesModal();

    const sideLabel = data.positionSide === 'SHORT' || data.side === 'Short' ? 'SHORT' : 'LONG';
    const pnlIsPositive = String(data.pnl || '').trim().startsWith('+');
    const pnlClass = pnlIsPositive ? 'pnl-positive' : 'pnl-negative';
    const leverageText = data.leverage || '--';
    const amountText = Number.isFinite(Number(data.positionAmt)) ? Math.abs(Number(data.positionAmt)) : '--';

    const html = `
        <div class="fut-close-details-grid">
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Sembol</span><span class="fut-close-detail-value">${data.symbol}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Yon</span><span class="fut-close-detail-value ${sideLabel === 'LONG' ? 'fut-cell-long' : 'fut-cell-short'}">${sideLabel}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Pozisyon</span><span class="fut-close-detail-value">${amountText}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Kaldirac</span><span class="fut-close-detail-value">${leverageText}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Entry Price</span><span class="fut-close-detail-value">${data.entryPrice}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Last Price</span><span class="fut-close-detail-value">${data.lastPrice}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Mark Price</span><span class="fut-close-detail-value">${data.markPrice}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Liq. Price</span><span class="fut-close-detail-value">${data.liqPrice}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Margin</span><span class="fut-close-detail-value">${data.margin}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">Margin Ratio</span><span class="fut-close-detail-value">${data.marginRatio}</span></div>
            <div class="fut-close-detail-row"><span class="fut-close-detail-label">ROE</span><span class="fut-close-detail-value">${data.roi}</span></div>
            <div class="fut-close-detail-row" style="grid-column:1/-1;margin-top:8px;padding-top:12px;border-top:1px solid var(--binance-border)">
                <span class="fut-close-detail-label">Bekleyen PnL</span>
                <span class="fut-close-detail-value ${pnlClass}">${data.pnl}</span>
            </div>
        </div>
        <p style="margin-top:16px;font-size:12px;color:var(--binance-text-secondary)">Bu pozisyonu kapatmak istediginizden emin misiniz?</p>
    `;

    const modal = document.getElementById('fut-close-position-modal');
    const detailsEl = document.getElementById('fut-close-position-details');
    const confirmBtn = document.getElementById('fut-close-position-confirm');

    if (detailsEl) {
        detailsEl.innerHTML = html;
    }
    if (confirmBtn) {
        confirmBtn.textContent = 'Close';
        confirmBtn.onclick = () => {
            closeClosePositionModal();
            confirmClosePosition(data.symbol, data.positionAmt, data.side, data.positionSide);
        };
    }
    if (modal) {
        modal.classList.add('open');
    }
}

function closeClosePositionModal() {
    document.getElementById('fut-close-position-modal')?.classList.remove('open');
}

function setClosePositionLoading(isLoading) {
    const confirmBtn = document.getElementById('fut-close-position-confirm');
    const closeBtn = document.querySelector('#fut-close-position-modal .fut-confirm-modal-close');
    const cancelBtn = document.querySelector('#fut-close-position-modal .fut-confirm-btn-secondary');

    if (confirmBtn) {
        confirmBtn.disabled = isLoading;
        confirmBtn.style.opacity = isLoading ? '0.7' : '1';
        confirmBtn.style.cursor = isLoading ? 'not-allowed' : 'pointer';
        confirmBtn.textContent = isLoading ? 'Closing...' : 'Close';
    }

    if (cancelBtn) {
        cancelBtn.disabled = isLoading;
        cancelBtn.style.opacity = isLoading ? '0.6' : '1';
        cancelBtn.style.cursor = isLoading ? 'not-allowed' : 'pointer';
    }

    if (closeBtn) {
        closeBtn.disabled = isLoading;
        closeBtn.style.opacity = isLoading ? '0.6' : '1';
        closeBtn.style.cursor = isLoading ? 'not-allowed' : 'pointer';
    }
}

function ensurePortfolioUsesFuturesModal() {
    let modal = document.getElementById('fut-close-position-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.className = 'fut-confirm-modal';
        modal.id = 'fut-close-position-modal';
        modal.innerHTML = `
            <div class="fut-confirm-modal-content fut-close-modal-wide">
                <div class="fut-confirm-modal-header">
                    <h3>Close Position</h3>
                    <button type="button" class="fut-confirm-modal-close">✕</button>
                </div>
                <div class="fut-confirm-modal-body" id="fut-close-position-details"></div>
                <div class="fut-confirm-modal-footer">
                    <button type="button" class="fut-confirm-btn-secondary">Cancel</button>
                    <button type="button" class="fut-confirm-btn-danger" id="fut-close-position-confirm">Close</button>
                </div>
            </div>
        `;
        modal.addEventListener('click', function (e) {
            if (e.target === modal) {
                closeClosePositionModal();
            }
        });
        document.body.appendChild(modal);
    }

    const closeBtn = modal.querySelector('.fut-confirm-modal-close');
    const cancelBtn = modal.querySelector('.fut-confirm-btn-secondary');
    if (closeBtn) {
        closeBtn.onclick = () => closeClosePositionModal();
    }
    if (cancelBtn) {
        cancelBtn.onclick = () => closeClosePositionModal();
    }
}

function notifyClosePosition(message, type = 'info') {
    if (typeof window.showToast === 'function') {
        window.showToast(type, message);
        return;
    }

    if (typeof window.showNotification === 'function') {
        window.showNotification(message, type);
        return;
    }

    alert(message);
}

function refreshPortfolioAfterClose() {
    if (typeof loadPositions === 'function') {
        loadPositions(false);
    }
    if (typeof loadPortfolio === 'function') {
        loadPortfolio();
    }

    setTimeout(() => {
        if (typeof loadPositions === 'function') {
            loadPositions(false);
        }
        if (typeof loadPortfolio === 'function') {
            loadPortfolio();
        }
    }, 1200);
}

async function confirmClosePosition(symbol, positionAmt, side, positionSide) {
    if (typeof AUTH === 'undefined' || !AUTH || !AUTH.token) {
        console.error('[CLOSE POSITION] AUTH not found in confirmClosePosition');
        notifyClosePosition('Oturum bulunamadi. Lutfen tekrar giris yapin.', 'error');
        return;
    }

    console.log('[CLOSE POSITION] Confirming close:', { symbol, positionAmt, side, positionSide });

    try {
        setClosePositionLoading(true);

        const body = { symbol: symbol };
        if (positionSide && (positionSide === 'LONG' || positionSide === 'SHORT' || positionSide === 'BOTH')) {
            body.positionSide = positionSide;
        }

        const res = await fetch(API + '/binance/close-position', {
            method: 'POST',
            headers: {
                'Authorization': 'Bearer ' + AUTH.token,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(body)
        });

        const data = await res.json();
        console.log('[CLOSE POSITION] Response:', data);

        if (res.ok) {
            closeClosePositionModal();
            showSuccessNotification(`${symbol} pozisyonu basariyla kapatildi!`);
            refreshPortfolioAfterClose();
            return;
        }

        setClosePositionLoading(false);
        notifyClosePosition(`Pozisyon kapatilamadi: ${data.error || 'Bilinmeyen hata'}`, 'error');
    } catch (e) {
        console.error('[CLOSE POSITION] Error:', e);
        setClosePositionLoading(false);
        notifyClosePosition(`Hata: ${e.message}`, 'error');
    }
}

function showSuccessNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = 'position:fixed;top:20px;right:20px;background:#0ecb81;color:#fff;padding:16px 24px;border-radius:8px;font-size:14px;font-weight:600;box-shadow:0 4px 20px rgba(14,203,129,0.4);z-index:10000;animation:slideInRight 0.3s';
    notification.textContent = 'OK ' + message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

window.closePosition = closePosition;
window.closeClosePositionModal = closeClosePositionModal;
window.confirmClosePosition = confirmClosePosition;
window.showPortfolioClosePositionModal = showPortfolioClosePositionModal;
