(function () {
  const EXTRA_KEY = 'botSettingsExtra';
  const legacySave = window.saveBotSettings;
  const legacyLoad = window.loadBotSettings;

  function el(tag, className, html) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function setValue(id, value) {
    const node = document.getElementById(id);
    if (node && value !== undefined && value !== null) node.value = value;
  }

  function setChecked(id, value) {
    const node = document.getElementById(id);
    if (node && value !== undefined) node.checked = !!value;
  }

  function bindToggle(checkboxId, targetId, displayMode) {
    const checkbox = document.getElementById(checkboxId);
    const target = document.getElementById(targetId);
    if (!checkbox || !target) return;
    const sync = () => { target.style.display = checkbox.checked ? displayMode : 'none'; };
    if (!checkbox.dataset.bound) {
      checkbox.addEventListener('change', sync);
      checkbox.dataset.bound = '1';
    }
    sync();
  }

  function switchTab(button, panelId) {
    const shell = button.closest('.bpt-settings-shell');
    if (!shell) return;
    shell.querySelectorAll('.bpt-settings-tab').forEach((tab) => tab.classList.remove('active'));
    shell.querySelectorAll('.bpt-settings-panel').forEach((panel) => panel.classList.remove('active'));
    button.classList.add('active');
    const panel = shell.querySelector(`#${panelId}`);
    if (panel) panel.classList.add('active');
  }

  function selectEngine(engine) {
    document.querySelectorAll('#botpanel-admin .bpt-engine-card').forEach((card) => {
      card.classList.toggle('active', card.dataset.engine === engine);
    });
    setValue('bot-engine', engine);
    const entry = document.getElementById('entry-strategy');
    if (entry) entry.value = engine === 'ott-only' ? 'ott' : (engine === 'ott-rsi' ? 'ott-rsi' : 'custom');
  }

  function applyTemplate(name) {
    const value = name || document.getElementById('strategy-template')?.value || 'custom';
    const presets = {
      conservative: { maxPositions: 2, leverage: 5, minSignal: 82, sl: 1.5, dca: false },
      balanced: { maxPositions: 3, leverage: 10, minSignal: 72, sl: 2.0, dca: true },
      aggressive: { maxPositions: 5, leverage: 20, minSignal: 60, sl: 2.8, dca: true },
      scalping: { maxPositions: 6, leverage: 15, minSignal: 68, sl: 1.0, dca: false }
    };
    const preset = presets[value];
    if (!preset) {
      showNotification('Ozel ayar modu aktif', 'info');
      return;
    }
    setValue('max-positions', preset.maxPositions);
    setValue('leverage-slider', preset.leverage);
    const leverageLabel = document.getElementById('leverage-value');
    if (leverageLabel) leverageLabel.textContent = `${preset.leverage}x`;
    setValue('min-signal-score', preset.minSignal);
    setValue('sl-percent', preset.sl);
    setChecked('dca-enabled', preset.dca);
    bindToggle('dca-enabled', 'dca-settings', 'block');
    showNotification('Preset gorunume uygulandi', 'success');
  }

  function buildTabs(sidebar, sections) {
    const shell = el('div', 'bpt-sec bpt-settings-shell');
    shell.style.borderBottom = 'none';
    const tabs = el('div', 'bpt-settings-tabs');
    const panels = {
      general: el('div', 'bpt-settings-panel active'),
      strategy: el('div', 'bpt-settings-panel'),
      entry: el('div', 'bpt-settings-panel'),
      exit: el('div', 'bpt-settings-panel'),
      dca: el('div', 'bpt-settings-panel'),
      risk: el('div', 'bpt-settings-panel')
    };

    panels.general.id = 'bp-panel-general';
    panels.strategy.id = 'bp-panel-strategy';
    panels.entry.id = 'bp-panel-entry';
    panels.exit.id = 'bp-panel-exit';
    panels.dca.id = 'bp-panel-dca';
    panels.risk.id = 'bp-panel-risk';

    [
      ['Genel', 'bp-panel-general'],
      ['Strateji', 'bp-panel-strategy'],
      ['Giris', 'bp-panel-entry'],
      ['Cikis', 'bp-panel-exit'],
      ['DCA', 'bp-panel-dca'],
      ['Risk', 'bp-panel-risk']
    ].forEach(([label, target], index) => {
      const btn = el('button', `bpt-settings-tab${index === 0 ? ' active' : ''}`, label);
      btn.type = 'button';
      btn.addEventListener('click', () => switchTab(btn, target));
      tabs.appendChild(btn);
    });

    const mapping = {
      general: [0, 1, 2],
      exit: [3],
      strategy: [4, 8],
      dca: [5],
      risk: [6, 7, 9]
    };

    Object.entries(mapping).forEach(([panelName, indexes]) => {
      indexes.forEach((i) => {
        const section = sections[i];
        if (!section) return;
        section.classList.add('bpt-panel-card');
        section.style.borderBottom = 'none';
        section.style.padding = '12px';
        section.style.background = '#0d0d0d';
        panels[panelName].appendChild(section);
      });
    });

    shell.appendChild(tabs);
    Object.values(panels).forEach((panel) => shell.appendChild(panel));
    sidebar.appendChild(shell);
  }

  function enhanceBotPanel() {
    const sidebar = document.querySelector('#botpanel-admin .bpt-sidebar');
    if (!sidebar || sidebar.dataset.enhanced === '1') return;
    const sections = Array.from(sidebar.querySelectorAll(':scope > .bpt-sec'));
    if (sections.length < 10) return;

    const intro = el('div', 'bpt-side-intro', `
      <div class="bpt-side-eyebrow">Control Center</div>
      <div class="bpt-side-title">Bot Paneli</div>
      <div class="bpt-side-copy">Sekmelenmis yapiyla bot secimi, giris kurallari, cikis planlari ve risk duvarlari tek akista duzenlendi.</div>
    `);
    sidebar.insertBefore(intro, sections[0]);

    sections.forEach((section) => section.remove());
    buildTabs(sidebar, sections);

    const marketSection = document.getElementById('bp-symbol')?.closest('.bpt-panel-card');
    if (marketSection && !document.getElementById('bp-ott-val')) {
      const snapshot = el('div', '', `
        <div class="bpt-hero-grid" style="margin-top:12px">
          <div class="bpt-panel-card"><div class="bpt-panel-sub" style="margin-bottom:6px">OTT</div><div class="bpt-panel-title" id="bp-ott-val">--</div><div class="bpt-toggle-copy" id="bp-ott-signal-sub">Sinyal bekleniyor</div></div>
          <div class="bpt-panel-card"><div class="bpt-panel-sub" style="margin-bottom:6px">MAvg</div><div class="bpt-panel-title" id="bp-mavg-val">--</div><div class="bpt-toggle-copy" id="bp-trend-sub">Trend bekleniyor</div></div>
        </div>
        <div class="bpt-hero-grid" style="margin-top:8px">
          <div class="bpt-panel-card"><div class="bpt-panel-sub" style="margin-bottom:6px">Fark</div><div class="bpt-panel-title" id="bp-fark-val">--</div></div>
          <div class="bpt-panel-card"><div class="bpt-panel-sub" style="margin-bottom:6px">Seans</div><select class="bpt-sel" id="session-filter"><option value="all">Tum Gun</option><option value="london">London</option><option value="ny">New York</option><option value="asia">Asia</option></select></div>
        </div>
      `);
      marketSection.appendChild(snapshot);
    }

    const statusSection = document.getElementById('bot-mode')?.closest('.bpt-panel-card');
    if (statusSection && !statusSection.querySelector('.bpt-quick-grid')) {
      const templateBlock = el('div', 'bpt-hero-grid');
      templateBlock.style.marginTop = '12px';
      templateBlock.innerHTML = `
        <div><div class="bpt-lbl">Preset</div><select class="bpt-sel" id="strategy-template"><option value="custom">Ozel Ayarlar</option><option value="conservative">Muhafazakar</option><option value="balanced">Dengeli</option><option value="aggressive">Agresif</option><option value="scalping">Scalping</option></select></div>
        <div><div class="bpt-lbl">Yon</div><select class="bpt-sel" id="trade-direction"><option value="both">Long + Short</option><option value="long">Sadece Long</option><option value="short">Sadece Short</option></select></div>
      `;
      statusSection.appendChild(templateBlock);
      statusSection.insertAdjacentHTML('beforeend', `
        <div class="bpt-quick-grid">
          <button class="bpt-quick-action success" type="button" id="bp-template-apply">Preset Yukle</button>
          <button class="bpt-quick-action" type="button" onclick="showNotification('Canli on izleme gorunumu hazir', 'info')">On Izleme</button>
          <button class="bpt-quick-action danger" type="button" onclick="showNotification('Acil durdurma backend geldikten sonra calisacak', 'info')">Acil Durdur</button>
        </div>
      `);
      statusSection.querySelector('#bp-template-apply')?.addEventListener('click', () => applyTemplate());
    }

    const strategySection = document.getElementById('entry-strategy')?.closest('.bpt-panel-card');
    if (strategySection && !document.getElementById('bot-engine')) {
      const engine = el('div', 'bpt-stack', `
        <div class="bpt-panel-title">Bot Motoru</div>
        <div class="bpt-panel-sub">Hangi strateji cekirdegi kullanilacak.</div>
        <input type="hidden" id="bot-engine" value="ott-rsi">
        <div class="bpt-engine-grid">
          <button class="bpt-engine-card active" type="button" data-engine="ott-rsi"><div class="bpt-engine-name">OTT + RSI</div><div class="bpt-engine-desc">Trend ve momentum dengesi.</div></button>
          <button class="bpt-engine-card" type="button" data-engine="ott-only"><div class="bpt-engine-name">OTT</div><div class="bpt-engine-desc">Sade trend takibi.</div></button>
          <button class="bpt-engine-card" type="button" data-engine="ema-cross"><div class="bpt-engine-name">EMA Cross</div><div class="bpt-engine-desc">Kesisim bazli sinyal.</div></button>
          <button class="bpt-engine-card" type="button" data-engine="scalp"><div class="bpt-engine-name">Scalp</div><div class="bpt-engine-desc">Kisa sureli akisi hedefler.</div></button>
        </div>
      `);
      strategySection.prepend(engine);
      strategySection.querySelectorAll('.bpt-engine-card').forEach((card) => {
        card.addEventListener('click', () => selectEngine(card.dataset.engine));
      });
    }

    if (strategySection && !document.getElementById('min-signal-score')) {
      strategySection.insertAdjacentHTML('beforeend', `
        <div class="bpt-stack" style="margin-top:12px">
          <div class="bpt-panel-title">Giris Filtreleri</div>
          <div class="bpt-two"><div><div class="bpt-lbl">Min Sinyal Skoru</div><input id="min-signal-score" class="bpt-inp" type="number" value="72"></div><div><div class="bpt-lbl">Mum Onayi</div><input id="signal-confirmation" class="bpt-inp" type="number" value="2"></div></div>
          <div class="bpt-two"><div><div class="bpt-lbl">Pullback %</div><input id="pullback-entry" class="bpt-inp" type="number" value="0.6" step="0.1"></div><div><div class="bpt-lbl">Breakout Buffer %</div><input id="breakout-buffer" class="bpt-inp" type="number" value="0.4" step="0.1"></div></div>
          <label class="bpt-toggle-line"><span>Trend Filtresi<div class="bpt-toggle-copy">Ana trend ile ayni yonde islem ac.</div></span><input type="checkbox" id="trend-filter" checked></label>
          <label class="bpt-toggle-line"><span>Hacim Onayi<div class="bpt-toggle-copy">Yetersiz hacimde isleme girme.</div></span><input type="checkbox" id="volume-confirmation" checked></label>
          <label class="bpt-toggle-line"><span>Yeniden Giris<div class="bpt-toggle-copy">Ayni yone tekrar girmeden once bekle.</div></span><input type="checkbox" id="allow-reentry" checked></label>
          <div><div class="bpt-lbl">Cooldown (dk)</div><input id="entry-cooldown" class="bpt-inp" type="number" value="20"></div>
        </div>
      `);
    }

    const exitSection = document.getElementById('tp-enabled')?.closest('.bpt-panel-card');
    if (exitSection && !document.getElementById('profit-lock-enabled')) {
      exitSection.insertAdjacentHTML('beforeend', `
        <div class="bpt-stack" style="margin-top:12px">
          <label class="bpt-toggle-line"><span>Kar Kilitle<div class="bpt-toggle-copy">Belirli kara gelince stop seviyesini yukari ceker.</div></span><input type="checkbox" id="profit-lock-enabled" checked></label>
          <div class="bpt-two" id="profit-lock-settings"><div><div class="bpt-lbl">Baslangic %</div><input id="profit-lock-start" class="bpt-inp" type="number" value="1.8" step="0.1"></div><div><div class="bpt-lbl">Adim %</div><input id="profit-lock-step" class="bpt-inp" type="number" value="0.4" step="0.1"></div></div>
          <label class="bpt-toggle-line"><span>Breakeven<div class="bpt-toggle-copy">Belirli kara gelince stopu girise cek.</div></span><input type="checkbox" id="breakeven-enabled"></label>
          <div class="bpt-two"><div><div class="bpt-lbl">Breakeven Tetik %</div><input id="breakeven-trigger" class="bpt-inp" type="number" value="0.8" step="0.1"></div><div><div class="bpt-lbl">Max Bekleme Saat</div><input id="max-holding-hours" class="bpt-inp" type="number" value="18"></div></div>
        </div>
      `);
    }

    const riskSection = document.getElementById('daily-loss-limit')?.closest('.bpt-panel-card');
    if (riskSection && !document.getElementById('loss-streak-limit')) {
      riskSection.insertAdjacentHTML('beforeend', `
        <div class="bpt-stack" style="margin-top:12px">
          <div><div class="bpt-lbl">Ardisik Zarar Limiti</div><input id="loss-streak-limit" class="bpt-inp" type="number" value="3"></div>
          <label class="bpt-toggle-line"><span>Hafta Sonu Pasif<div class="bpt-toggle-copy">Hafta sonu yeni islem acma.</div></span><input type="checkbox" id="weekend-mode"></label>
        </div>
      `);
    }

    const notificationSection = document.getElementById('notification-channel')?.closest('.bpt-panel-card');
    if (notificationSection) {
      const inputs = notificationSection.querySelectorAll('input[type=\"checkbox\"]');
      if (inputs[0]) inputs[0].id = 'notify-open';
      if (inputs[1]) inputs[1].id = 'notify-close';
      if (inputs[2]) inputs[2].id = 'notify-critical';
      if (inputs[3]) inputs[3].id = 'notify-report';
    }

    const saveSection = Array.from(sidebar.querySelectorAll('.bpt-panel-card')).find((card) => card.textContent.includes('AYARLARI KAYDET'));
    if (saveSection) {
      const saveInfo = saveSection.querySelector('div[style*=\"text-align:center\"]');
      if (saveInfo) saveInfo.id = 'bp-settings-save-time';
    }

    sidebar.dataset.enhanced = '1';
    bindToggle('trailing-sl', 'trailing-sl-settings', 'grid');
    bindToggle('dca-enabled', 'dca-settings', 'block');
    bindToggle('profit-lock-enabled', 'profit-lock-settings', 'grid');
  }

  window.saveBotSettings = function () {
    if (typeof legacySave === 'function') legacySave();
    const extra = {
      strategyTemplate: document.getElementById('strategy-template')?.value,
      tradeDirection: document.getElementById('trade-direction')?.value,
      sessionFilter: document.getElementById('session-filter')?.value,
      botEngine: document.getElementById('bot-engine')?.value,
      minSignalScore: document.getElementById('min-signal-score')?.value,
      signalConfirmation: document.getElementById('signal-confirmation')?.value,
      pullbackEntry: document.getElementById('pullback-entry')?.value,
      breakoutBuffer: document.getElementById('breakout-buffer')?.value,
      trendFilter: document.getElementById('trend-filter')?.checked,
      volumeConfirmation: document.getElementById('volume-confirmation')?.checked,
      allowReentry: document.getElementById('allow-reentry')?.checked,
      entryCooldown: document.getElementById('entry-cooldown')?.value,
      profitLockEnabled: document.getElementById('profit-lock-enabled')?.checked,
      profitLockStart: document.getElementById('profit-lock-start')?.value,
      profitLockStep: document.getElementById('profit-lock-step')?.value,
      breakevenEnabled: document.getElementById('breakeven-enabled')?.checked,
      breakevenTrigger: document.getElementById('breakeven-trigger')?.value,
      maxHoldingHours: document.getElementById('max-holding-hours')?.value,
      lossStreakLimit: document.getElementById('loss-streak-limit')?.value,
      weekendMode: document.getElementById('weekend-mode')?.checked,
      notifyOpen: document.getElementById('notify-open')?.checked,
      notifyClose: document.getElementById('notify-close')?.checked,
      notifyCritical: document.getElementById('notify-critical')?.checked,
      notifyReport: document.getElementById('notify-report')?.checked
    };
    localStorage.setItem(EXTRA_KEY, JSON.stringify(extra));
    const saveTime = document.getElementById('bp-settings-save-time');
    if (saveTime) saveTime.textContent = `Son kayit: ${new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}`;
  };

  window.loadBotSettings = function () {
    if (typeof legacyLoad === 'function') legacyLoad();
    enhanceBotPanel();
    const raw = localStorage.getItem(EXTRA_KEY);
    if (!raw) return;
    try {
      const extra = JSON.parse(raw);
      Object.entries(extra).forEach(([key, value]) => {
        const idMap = {
          strategyTemplate: 'strategy-template',
          tradeDirection: 'trade-direction',
          sessionFilter: 'session-filter',
          botEngine: 'bot-engine',
          minSignalScore: 'min-signal-score',
          signalConfirmation: 'signal-confirmation',
          pullbackEntry: 'pullback-entry',
          breakoutBuffer: 'breakout-buffer',
          trendFilter: 'trend-filter',
          volumeConfirmation: 'volume-confirmation',
          allowReentry: 'allow-reentry',
          entryCooldown: 'entry-cooldown',
          profitLockEnabled: 'profit-lock-enabled',
          profitLockStart: 'profit-lock-start',
          profitLockStep: 'profit-lock-step',
          breakevenEnabled: 'breakeven-enabled',
          breakevenTrigger: 'breakeven-trigger',
          maxHoldingHours: 'max-holding-hours',
          lossStreakLimit: 'loss-streak-limit',
          weekendMode: 'weekend-mode',
          notifyOpen: 'notify-open',
          notifyClose: 'notify-close',
          notifyCritical: 'notify-critical',
          notifyReport: 'notify-report'
        };
        const target = idMap[key];
        if (!target) return;
        if (typeof value === 'boolean') setChecked(target, value);
        else setValue(target, value);
      });
      selectEngine(extra.botEngine || 'ott-rsi');
      bindToggle('trailing-sl', 'trailing-sl-settings', 'grid');
      bindToggle('dca-enabled', 'dca-settings', 'block');
      bindToggle('profit-lock-enabled', 'profit-lock-settings', 'grid');
    } catch (error) {
      console.error('[BOT PANEL UI] extra load failed', error);
    }
  };

  window.bpApplyTemplate = applyTemplate;
  window.bpSelectEngine = selectEngine;
  document.addEventListener('DOMContentLoaded', () => {
    enhanceBotPanel();
    window.loadBotSettings();
  });
})();
