/* BINANCE FUTURES TRADING - MINIMAL VERSION */

// Global state
let currentFutPair = 'ETHUSDT';
let orderBookUpdateInterval = null;
let marketTradesUpdateInterval = null;
let futuresAccountPositionsInterval = null;
let futuresPositionsInterval = null;
/** Binance GET /fapi/v1/positionSide/dual — emirlerde positionSide gerekir */
let futuresHedgeMode = false;

/**
 * Admin API ekranından kaydedilen anahtarlar (bot_configs) ile uyumlu:
 * önce kaldıraç, sonra POST /api/binance/order — /api/binance/futures/order diye bir route yok.
 */
/** Binance API hata mesajını kullanıcı dostu Türkçe'ye çevir */
function formatBinanceError(err) {
  if (!err || typeof err !== 'string') return err || 'Operation failed';
  const s = err.toLowerCase();
  if (s.includes('insufficient') || s.includes('balance')) return 'Insufficient balance';
  if (s.includes('min notional') || s.includes('minnotional')) return 'Minimum order value not met';
  if (s.includes('precision') || s.includes('lot size') || s.includes('-1111')) return 'Invalid quantity or price precision';
  if (s.includes('price')) return 'Invalid price';
  if (s.includes('quantity') || s.includes('qty')) return 'Invalid quantity';
  if (s.includes('leverage')) return 'Could not set leverage';
  if (s.includes('reduce only') || s.includes('reduceonly')) return 'Reduce-only rule violated';
  if (s.includes('position') && s.includes('close')) return 'Pozisyon kapatılamadı';
  if (s.includes('timestamp')) return 'Zaman uyumsuzluğu - saati kontrol edin';
  if (s.includes('signature') || s.includes('api')) return 'API anahtarı hatası';
  if (s.includes('rate limit')) return 'Çok fazla istek - biraz bekleyin';
  return err;
}

/** "10x" veya eleman metninden kaldıraç (1–125). */
function parseFutLeverage(value) {
  if (value == null) return 10;
  const s = typeof value === 'string' ? value : (value.textContent != null ? value.textContent : String(value));
  const n = parseInt(String(s).replace(/[^0-9]/g, ''), 10);
  if (!isFinite(n) || n < 1) return 10;
  return Math.min(125, n);
}

/** Demo USDT-M ETHUSDT: genelde adım 0.001 (Binance -1111 hatasını azaltır). */
function futuresRoundQtyBase(qty) {
  const n = parseFloat(qty);
  if (!isFinite(n) || n <= 0) return null;
  const step = 0.001;
  const rounded = Math.floor(n / step) * step;
  if (rounded < step) return null;
  return parseFloat(rounded.toFixed(3));
}

async function refreshFuturesDualSide() {
  if (!AUTH?.token) {
    futuresHedgeMode = false;
    const b = document.getElementById('fut-hedge-badge');
    if (b) b.textContent = '';
    return;
  }
  try {
    const r = await fetch(API + '/binance/dual-side', { headers: { Authorization: 'Bearer ' + AUTH.token } });
    const d = await r.json();
    futuresHedgeMode = !!d.dualSidePosition;
    const badge = document.getElementById('fut-hedge-badge');
    if (badge) badge.textContent = futuresHedgeMode ? 'Hedge' : 'One-way';
  } catch (e) {
    futuresHedgeMode = false;
    const badge = document.getElementById('fut-hedge-badge');
    if (badge) badge.textContent = '';
  }
}

function futuresApplyHedgeToOpenOrder(orderData) {
  if (!futuresHedgeMode) return;
  if (orderData.side === 'BUY') orderData.positionSide = 'LONG';
  else if (orderData.side === 'SELL') orderData.positionSide = 'SHORT';
}

function futFmtTime(ms) {
  if (ms == null || ms === '') return '—';
  try {
    return new Date(ms).toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'medium' });
  } catch (e) {
    return '—';
  }
}

const FUT_BOTTOM_PANEL_LABELS = {
  positions: 'Positions',
  'open-orders': 'Open Orders',
  'order-history': 'Order History',
  'trade-history': 'Trade History',
  assets: 'Assets'
};

function updateFutBottomPanelTitle(tab) {
  const titleEl = document.getElementById('fut-bottom-panel-title');
  if (!titleEl) return;
  const label = FUT_BOTTOM_PANEL_LABELS[tab] || 'Positions';
  if (tab === 'assets') {
    titleEl.innerHTML = 'Assets <span style="opacity:0.75;font-weight:500;font-size:10px;margin-left:6px">(USDT-M cüzdan)</span>';
  } else {
    titleEl.innerHTML = label + ' — <span id="fut-bottom-pair-label">' + currentFutPair + '</span>';
  }
}

async function binanceFuturesSendOrder(leverage, orderBody) {
  const sym = orderBody.symbol || currentFutPair;
  const lev = parseFutLeverage(leverage);
  
  console.log('[ORDER] Sending order:', {
    symbol: sym,
    leverage: lev,
    orderBody: orderBody
  });
  
  if (AUTH?.token) {
    const leverageRes = await fetch(API + '/binance/leverage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + AUTH.token },
      body: JSON.stringify({ symbol: sym, leverage: lev })
    });
    
    if (!leverageRes.ok) {
      const leverageError = await leverageRes.json();
      console.error('[ORDER] Leverage set failed:', leverageError);
    } else {
      console.log('[ORDER] Leverage set to', lev + 'x');
    }
  }
  
  const payload = { ...orderBody };
  delete payload.leverage;
  
  if (payload.quantity != null) {
    const rq = futuresRoundQtyBase(payload.quantity);
    if (rq != null) payload.quantity = rq;
  }
  
  console.log('[ORDER] Final payload:', payload);
  
  const response = await fetch(API + '/binance/order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + AUTH.token },
    body: JSON.stringify(payload)
  });
  
  const responseData = await response.json();
  console.log('[ORDER] Response:', response.status, responseData);
  
  // Return a new response with the data
  return new Response(JSON.stringify(responseData), {
    status: response.status,
    headers: { 'Content-Type': 'application/json' }
  });
}

// Initialize
async function initBinanceTrading() {
  console.log('[FUTURES] Initializing...');
  
  // Restore saved leverage values
  const savedLongLeverage = localStorage.getItem('fut-long-leverage');
  const savedShortLeverage = localStorage.getItem('fut-short-leverage');
  
  if (savedLongLeverage) {
    document.getElementById('fut-long-leverage-value').textContent = savedLongLeverage + 'x';
  }
  
  if (savedShortLeverage) {
    document.getElementById('fut-short-leverage-value').textContent = savedShortLeverage + 'x';
  }
  
  await loadFuturesPage();
  startBinanceAutoRefresh();
  
  // Auto-fill current price after a short delay
  setTimeout(() => {
    fillCurrentPrice();
  }, 1000);
}

// Fill current price into inputs
function fillCurrentPrice() {
  const priceEl = document.getElementById('fut-current-price');
  if (priceEl && priceEl.textContent && priceEl.textContent !== '—') {
    const currentPrice = priceEl.textContent.replace(/[^0-9.]/g, '');
    
    const longPriceInput = document.getElementById('fut-long-price');
    const shortPriceInput = document.getElementById('fut-short-price');
    
    if (longPriceInput && !longPriceInput.value) {
      longPriceInput.value = currentPrice;
      updateFutLongCost();
    }
    
    if (shortPriceInput && !shortPriceInput.value) {
      shortPriceInput.value = currentPrice;
      updateFutShortCost();
    }
  }
}

// Load all data
async function loadFuturesPage() {
  console.log('[FUTURES] Loading page data...');
  const active = document.querySelector('.binance-bottom-tab.active');
  const tabNow = (active && active.dataset && active.dataset.tab) || 'positions';
  updateFutBottomPanelTitle(tabNow);
  
  // Load fast public data sequentially to avoid connection flood
  await loadFutOrderBook();
  await loadFutMarketTrades();
  await loadFut24hStats();
  
  if (AUTH && AUTH.token) {
    // Load slower private data sequentially
    await loadFutAccountInfo();
    await loadFutPositions();
    await refreshFuturesDualSide();
    await loadFutOpenOrders();
    await loadFutOrderHistory();
    await loadFutTradeHistory();
    await loadFutAssets();
  }
}

// Order Book
async function loadFutOrderBook() {
  console.log('[FUTURES] Loading order book...');
  const asksContainer = document.getElementById('fut-orderbook-asks');
  const bidsContainer = document.getElementById('fut-orderbook-bids');
  const priceEl = document.getElementById('fut-current-price');
  
  if (!asksContainer || !bidsContainer) return;
  
  try {
    const response = await fetch(`${API}/binance/public/orderbook?symbol=${currentFutPair}&limit=20`);
    const data = await response.json();
    
    const allQty = [...data.asks.slice(0,15), ...data.bids.slice(0,15)].map(([_,q]) => parseFloat(q));
    const maxQty = Math.max(...allQty);
    
    asksContainer.innerHTML = data.asks.slice(0,15).reverse().map(([price, qty]) => {
      const depth = (parseFloat(qty) / maxQty * 100).toFixed(0);
      return `<div class="binance-orderbook-row" style="--depth-color:var(--binance-red);--depth-width:${depth}%">
        <div class="binance-orderbook-cell">${parseFloat(price).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2})}</div>
        <div class="binance-orderbook-cell">${parseFloat(qty).toFixed(4)}</div>
        <div class="binance-orderbook-cell">${(parseFloat(price) * parseFloat(qty)).toFixed(2)}</div>
      </div>`;
    }).join('');
    
    bidsContainer.innerHTML = data.bids.slice(0,15).map(([price, qty]) => {
      const depth = (parseFloat(qty) / maxQty * 100).toFixed(0);
      return `<div class="binance-orderbook-row" style="--depth-color:var(--binance-green);--depth-width:${depth}%">
        <div class="binance-orderbook-cell">${parseFloat(price).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2})}</div>
        <div class="binance-orderbook-cell">${parseFloat(qty).toFixed(4)}</div>
        <div class="binance-orderbook-cell">${(parseFloat(price) * parseFloat(qty)).toFixed(2)}</div>
      </div>`;
    }).join('');
    
    if (priceEl && data.bids.length > 0) {
      const formattedPrice = parseFloat(data.bids[0][0]).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
      priceEl.textContent = formattedPrice;
      // Update toolbar live price
      const toolbarPrice = document.getElementById('fut-toolbar-live-price');
      if (toolbarPrice) toolbarPrice.textContent = formattedPrice;
      
      // Auto-fill price inputs if empty
      const currentPrice = data.bids[0][0];
      const longPriceInput = document.getElementById('fut-long-price');
      const shortPriceInput = document.getElementById('fut-short-price');
      
      if (longPriceInput && !longPriceInput.value) {
        longPriceInput.value = parseFloat(currentPrice).toFixed(2);
        updateFutLongCost();
      }
      
      if (shortPriceInput && !shortPriceInput.value) {
        shortPriceInput.value = parseFloat(currentPrice).toFixed(2);
        updateFutShortCost();
      }
    }
    
    console.log('[FUTURES] Order book loaded');
  } catch (e) {
    console.error('[FUTURES] Order book error:', e);
  }
}

// Market Trades
async function loadFutMarketTrades() {
  console.log('[FUTURES] Loading market trades...');
  const container = document.getElementById('fut-market-trades');
  if (!container) return;
  
  try {
    const response = await fetch(`${API}/binance/public/trades?symbol=${currentFutPair}&limit=50`);
    const data = await response.json();
    
    container.innerHTML = data.slice(0,30).map(trade => {
      const isBuy = trade.isBuyerMaker === false;
      const time = new Date(trade.time).toLocaleTimeString('en-US', {hour:'2-digit', minute:'2-digit', second:'2-digit'});
      return `<div class="binance-market-trades-row">
        <div class="binance-market-trades-cell" style="color:${isBuy ? 'var(--binance-green)' : 'var(--binance-red)'}">${parseFloat(trade.price).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2})}</div>
        <div class="binance-market-trades-cell">${parseFloat(trade.qty).toFixed(4)}</div>
        <div class="binance-market-trades-cell">${time}</div>
      </div>`;
    }).join('');
    
    console.log('[FUTURES] Market trades loaded');
  } catch (e) {
    console.error('[FUTURES] Market trades error:', e);
  }
}

// 24h Stats
async function loadFut24hStats() {
  console.log('[FUTURES] Loading 24h stats...');
  try {
    const response = await fetch(`${API}/binance/public/ticker24h?symbol=${currentFutPair}`);
    const data = await response.json();
    
    const changeEl = document.getElementById('fut-24h-change');
    const highEl = document.getElementById('fut-24h-high');
    const lowEl = document.getElementById('fut-24h-low');
    const volumeEl = document.getElementById('fut-24h-volume');
    
    if (changeEl) {
      const change = parseFloat(data.priceChange);
      const changePercent = parseFloat(data.priceChangePercent);
      const isPositive = change >= 0;
      changeEl.textContent = `${isPositive ? '+' : ''}${change.toFixed(2)} ${isPositive ? '+' : ''}${changePercent.toFixed(2)}%`;
      changeEl.className = `binance-price-value ${isPositive ? 'green' : 'red'}`;
    }
    if (highEl) highEl.textContent = parseFloat(data.highPrice).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    if (lowEl) lowEl.textContent = parseFloat(data.lowPrice).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    if (volumeEl) volumeEl.textContent = (parseFloat(data.quoteVolume) / 1000000000).toFixed(2) + 'B';
    
    console.log('[FUTURES] 24h stats loaded');
  } catch (e) {
    console.error('[FUTURES] 24h stats error:', e);
  }
}

// Auto-refresh
function startBinanceAutoRefresh() {
  if (orderBookUpdateInterval) clearInterval(orderBookUpdateInterval);
  if (marketTradesUpdateInterval) clearInterval(marketTradesUpdateInterval);
  
  orderBookUpdateInterval = setInterval(() => {
    if (document.getElementById('dash-futures')?.style.display !== 'none') {
      loadFutOrderBook();
    }
  }, 3000);
  
  marketTradesUpdateInterval = setInterval(() => {
    if (document.getElementById('dash-futures')?.style.display !== 'none') {
      loadFutMarketTrades();
    }
  }, 3000);

  if (futuresAccountPositionsInterval) clearInterval(futuresAccountPositionsInterval);
  futuresAccountPositionsInterval = setInterval(async () => {
    if (document.getElementById('dash-futures')?.style.display !== 'none') {
      if (AUTH && AUTH.token) {
        await loadFutAccountInfo();
        await refreshFuturesDualSide();
        await loadFutOpenOrders();
        await loadFutOrderHistory();
        await loadFutTradeHistory();
        await loadFutAssets();
      }
    }
  }, 10000);
  
  if (futuresPositionsInterval) clearInterval(futuresPositionsInterval);
  futuresPositionsInterval = setInterval(async () => {
    if (document.getElementById('dash-futures')?.style.display !== 'none') {
      if (AUTH && AUTH.token) {
        await loadFutPositions();
      }
    }
  }, 1000);
  
  console.log('[FUTURES] Auto-refresh started');
}

function stopBinanceAutoRefresh() {
  if (orderBookUpdateInterval) clearInterval(orderBookUpdateInterval);
  if (marketTradesUpdateInterval) clearInterval(marketTradesUpdateInterval);
  if (futuresAccountPositionsInterval) clearInterval(futuresAccountPositionsInterval);
  if (futuresPositionsInterval) clearInterval(futuresPositionsInterval);
}

// Register globally
window.initBinanceTrading = initBinanceTrading;
window.stopBinanceAutoRefresh = stopBinanceAutoRefresh;

console.log('[FUTURES] Minimal version loaded');


// Account Info
async function loadFutAccountInfo() {
  console.log('[FUTURES] Loading account info...');
  try {
    const response = await fetch(`${API}/binance/account`, {
      headers: { 'Authorization': 'Bearer ' + (AUTH?.token || '') }
    });
    
    if (!response.ok) {
      const errEl = document.getElementById('fut-balance');
      if (errEl) {
        errEl.textContent = 'API not connected';
        errEl.style.color = 'var(--binance-red)';
      }
      const avL = document.getElementById('fut-long-available');
      const avS = document.getElementById('fut-short-available');
      if (avL) avL.textContent = '— Enter key in API Settings';
      if (avS) avS.textContent = '— Enter key in API Settings';
      currentBalance = 0;
      return;
    }
    
    const data = await response.json();
    const balanceEl = document.getElementById('fut-balance');
    if (balanceEl) balanceEl.style.color = '';
    updateAccountUI(data);
    console.log('[FUTURES] Account info loaded');
  } catch (e) {
    console.error('[FUTURES] Account info error:', e);
  }
}

function updateAccountUI(data) {
  const balanceEl = document.getElementById('fut-balance');
  const unrealizedPnlEl = document.getElementById('fut-unrealized-pnl');
  const marginBalanceEl = document.getElementById('fut-margin-balance');
  const marginRatioEl = document.getElementById('fut-margin-ratio');
  const marginGaugeEl = document.getElementById('fut-margin-gauge');
  const maintMarginEl = document.getElementById('fut-maint-margin');
  
  const balance = data.totalWalletBalance || 0;
  const unrealizedPnl = data.totalUnrealizedProfit || 0;
  const marginBalance = data.totalMarginBalance || (balance + unrealizedPnl);
  const availBalance = data.availableBalance ?? balance;
  const totalMaintMargin = data.totalMaintMargin || 0;
  
  // Update global balance ve available
  currentBalance = balance;
  currentAvailableBalance = availBalance;
  
  // Update available balance displays
  const avblStr = availBalance.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}) + ' USDT';
  const avblL = document.getElementById('fut-long-available');
  const avblS = document.getElementById('fut-short-available');
  if (avblL) avblL.textContent = avblStr;
  if (avblS) avblS.textContent = avblStr;
  
  if (balanceEl) balanceEl.textContent = balance.toLocaleString('en-US', {minimumFractionDigits:4, maximumFractionDigits:4}) + ' USDT';
  if (unrealizedPnlEl) {
    unrealizedPnlEl.textContent = unrealizedPnl.toLocaleString('en-US', {minimumFractionDigits:4, maximumFractionDigits:4}) + ' USDT';
    unrealizedPnlEl.className = 'binance-account-value ' + (unrealizedPnl >= 0 ? 'green' : 'red');
  }
  if (marginBalanceEl) marginBalanceEl.textContent = marginBalance.toLocaleString('en-US', {minimumFractionDigits:4, maximumFractionDigits:4}) + ' USDT';
  
  // Margin ratio = (totalMaintMargin / totalMarginBalance) * 100
  let marginRatio = 0;
  if (marginBalance > 0 && totalMaintMargin > 0) {
    marginRatio = (totalMaintMargin / marginBalance) * 100;
  }
  if (marginRatioEl) marginRatioEl.textContent = marginRatio.toFixed(2) + '%';
  if (marginGaugeEl) {
    marginGaugeEl.textContent = marginRatio.toFixed(0) + '%';
    marginGaugeEl.style.borderColor = marginRatio < 50 ? 'var(--binance-green)' : marginRatio < 80 ? 'var(--binance-yellow)' : 'var(--binance-red)';
  }
  if (maintMarginEl) maintMarginEl.textContent = totalMaintMargin.toLocaleString('en-US', {minimumFractionDigits:4, maximumFractionDigits:4}) + ' USDT';
  
  // Single/Multi-Asset Mode butonunu güncelle
  updateFutSingleAssetButton();
}

async function updateFutSingleAssetButton() {
  const btn = document.getElementById('fut-single-asset-btn');
  if (!btn || !AUTH?.token) return;
  try {
    const r = await fetch(API + '/binance/multi-assets-mode', { headers: { Authorization: 'Bearer ' + AUTH.token } });
    const d = await r.json();
    const isMulti = !!d.multiAssetsMargin;
    btn.textContent = isMulti ? 'Multi-Asset Mode' : 'Single-Asset Mode';
    btn.title = isMulti ? 'Şu an Multi-Asset. Tıkla: Single-Asset\'e geç' : 'Şu an Single-Asset. Tıkla: Multi-Asset\'e geç';
  } catch (e) {
    btn.textContent = 'Single-Asset Mode';
  }
}

async function toggleFutSingleAssetMode() {
  if (!AUTH?.token) {
    if (typeof showNotification === 'function') showNotification('Giriş yapın', 'error');
    return;
  }
  const btn = document.getElementById('fut-single-asset-btn');
  if (btn) btn.disabled = true;
  try {
    const r = await fetch(API + '/binance/multi-assets-mode', { headers: { Authorization: 'Bearer ' + AUTH.token } });
    const d = await r.json();
    const currentlyMulti = !!d.multiAssetsMargin;
    const newMulti = !currentlyMulti;
    
    const res = await fetch(API + '/binance/multi-assets-mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + AUTH.token },
      body: JSON.stringify({ multiAssetsMargin: newMulti })
    });
    const data = await res.json();
    
    if (res.ok) {
      const msg = newMulti ? 'Multi-Asset Mode active' : 'Single-Asset Mode active';
      if (typeof showNotification === 'function') showNotification(msg, 'success');
      loadFutAccountInfo();
    } else {
      if (typeof showNotification === 'function') showNotification(data.error || 'Could not be changed', 'error');
    }
  } catch (e) {
    if (typeof showNotification === 'function') showNotification('Connection error', 'error');
  } finally {
    if (btn) btn.disabled = false;
  }
}


// ═══════════════════════════════════════
// TRADING FUNCTIONS
// ═══════════════════════════════════════

let currentBalance = 10000; // Will be updated from API

// Update Long Leverage (programmatic)
function setFutLongLeverage(value) {
  const el = document.getElementById('fut-long-leverage-value');
  if (el) el.textContent = value + 'x';
  localStorage.setItem('fut-long-leverage', value);
  updateFutLongCost();
}

// Update Short Leverage (programmatic)
function setFutShortLeverage(value) {
  const el = document.getElementById('fut-short-leverage-value');
  if (el) el.textContent = value + 'x';
  localStorage.setItem('fut-short-leverage', value);
  updateFutShortCost();
}

// Set Long Percentage (Binance logic: percentage of balance used as margin)
function setFutLongPercentage(percent) {
  const levEl = document.getElementById('fut-long-leverage-value');
  const leverage = parseFutLeverage(levEl?.textContent);
  const price = parseFloat(document.getElementById('fut-long-price').value) || 0;
  
  if (!price) {
    showNotification('Enter price first', 'error');
    return;
  }
  
  // Margin = (Balance * 0.98) × (percent / 100) to account for fees!
  const bal = currentAvailableBalance > 0 ? currentAvailableBalance : currentBalance;
  const margin = (bal * 0.98) * (percent / 100);
  
  // Size = (Margin × Leverage) / Price
  const size = (margin * leverage) / price;
  
  document.getElementById('fut-long-size').value = size.toFixed(3);
  updateLongSizeSlider();
  updateFutLongCost();
}

// Set Short Percentage (Binance logic: percentage of balance used as margin)
function setFutShortPercentage(percent) {
  const levEl = document.getElementById('fut-short-leverage-value');
  const leverage = parseFutLeverage(levEl?.textContent);
  const price = parseFloat(document.getElementById('fut-short-price').value) || 0;
  
  if (!price) {
    showNotification('Enter price first', 'error');
    return;
  }
  
  // Margin = (Balance * 0.98) × (percent / 100) to account for fees!
  const bal = currentAvailableBalance > 0 ? currentAvailableBalance : currentBalance;
  const margin = (bal * 0.98) * (percent / 100);
  
  // Size = (Margin × Leverage) / Price
  const size = (margin * leverage) / price;
  
  document.getElementById('fut-short-size').value = size.toFixed(3);
  updateShortSizeSlider();
  updateFutShortCost();
}

// Load Positions
async function loadFutPositions() {
  if (!AUTH || !AUTH.token) return;
  
  try {
    const response = await fetch(API + '/binance/positions', {
      headers: { 'Authorization': 'Bearer ' + AUTH.token }
    });
    
    if (!response.ok) return;
    
    const data = await response.json();
    const tbody = document.getElementById('fut-positions-tbody');
    
    if (!tbody) return;
    
    if (!data.positions || data.positions.length === 0) {
      tbody.innerHTML = `<tr>
        <td colspan="9" style="text-align:center;padding:60px;color:var(--binance-text-secondary)">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" style="margin:0 auto 16px;opacity:0.3">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="9" y1="9" x2="15" y2="15"/>
            <line x1="15" y1="9" x2="9" y2="15"/>
          </svg>
          <div>No open positions</div>
        </td>
      </tr>`;
      document.getElementById('fut-positions-count').textContent = '0';
      return;
    }
    
    document.getElementById('fut-positions-count').textContent = data.positions.length;
    window._futPositionsCache = data.positions;
    
    // Yüklenen pozisyonlar içinden anlık sembole ait olanı bul ve marginType arayüzünü ona göre güncelle
    const currentPairPos = data.positions.find(p => p.symbol === (typeof currentFutPair !== 'undefined' ? currentFutPair : 'BTCUSDT'));
    if (currentPairPos && currentPairPos.marginType) {
      const mode = currentPairPos.marginType.toUpperCase() === 'ISOLATED' ? 'ISOLATED' : 'CROSSED';
      if (typeof currentMarginMode !== 'undefined') currentMarginMode = mode;
      const marginEl = document.getElementById('fut-margin-type-display');
      if (marginEl) marginEl.textContent = mode === 'ISOLATED' ? 'Isolated' : 'Cross';
      document.querySelectorAll('.fut-margin-type-display-form').forEach(el => {
        el.textContent = mode === 'ISOLATED' ? 'Isolated' : 'Cross';
      });
    }
    
    tbody.innerHTML = data.positions.map((pos, idx) => {
      const pnl = parseFloat(pos.unrealizedProfit || 0);
      const pnlClass = pnl >= 0 ? 'fut-pnl-green' : 'fut-pnl-red';
      const roe = parseFloat(pos.roe || 0);
      const marginRatioPct = (parseFloat(pos.marginRatio || 0) * 100).toFixed(2);
      const marginVal = parseFloat(pos.initialMargin || pos.isolatedMargin || 0);
      const posSide = pos.positionSide || (parseFloat(pos.positionAmt) > 0 ? 'LONG' : 'SHORT');
      const amt = parseFloat(pos.positionAmt);
      
      return `<tr>
        <td>${pos.symbol}</td>
        <td class="${posSide === 'LONG' ? 'fut-cell-long' : 'fut-cell-short'}">${amt}</td>
        <td>${parseFloat(pos.entryPrice).toFixed(2)}</td>
        <td>${parseFloat(pos.markPrice || pos.lastPrice || 0).toFixed(2)}</td>
        <td>${parseFloat(pos.liquidationPrice || 0).toFixed(2)}</td>
        <td>${marginRatioPct}%</td>
        <td>${marginVal.toFixed(2)}</td>
        <td class="${pnlClass}" style="font-weight:600">${pnl.toFixed(2)} (${roe.toFixed(2)}%)</td>
        <td style="text-align:right">
          <button type="button" style="background:#f6465d;color:#fff;border:none;border-radius:4px;padding:4px 12px;font-size:12px;font-weight:600;cursor:pointer;transition:opacity 0.2s" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'" onclick="showClosePositionModal(${idx})">Kapat</button>
        </td>
      </tr>`;
    }).join('');
    
  } catch (e) {
    console.error('Positions load error:', e);
  }
}

async function loadFutOpenOrders() {
  if (!AUTH?.token) return;
  const tbody = document.getElementById('fut-open-orders-tbody');
  const cnt = document.getElementById('fut-open-orders-count');
  if (!tbody) return;
  try {
    const r = await fetch(API + '/binance/orders?symbol=' + encodeURIComponent(currentFutPair), {
      headers: { Authorization: 'Bearer ' + AUTH.token }
    });
    const data = await r.json();
    if (!r.ok) {
      const msg = data.error || data._error || 'Emirler yüklenemedi';
      tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;padding:40px;color:var(--binance-red)">${msg}</td></tr>`;
      if (cnt) cnt.textContent = '0';
      return;
    }
    if (data._error && !(data.orders && data.orders.length)) {
      tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;padding:40px;color:var(--binance-red)">${data._error}</td></tr>`;
      if (cnt) cnt.textContent = '0';
      return;
    }
    const orders = data.orders || [];
    if (cnt) cnt.textContent = String(orders.length);
    if (orders.length === 0) {
      tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;padding:40px;color:var(--binance-text-secondary)">No open orders</td></tr>';
      return;
    }
    tbody.innerHTML = orders.map(o => {
      const oid = JSON.stringify(String(o.orderId));
      const symJs = JSON.stringify(o.symbol);
      const stopStr = o.stopPrice != null && !isNaN(Number(o.stopPrice)) ? Number(o.stopPrice).toFixed(2) : '—';
      const px = o.price != null && !isNaN(Number(o.price)) ? Number(o.price).toFixed(2) : '—';
      return `<tr>
        <td>${o.symbol}</td>
        <td class="${o.side === 'BUY' ? 'fut-cell-long' : 'fut-cell-short'}">${o.side}</td>
        <td>${o.positionSide || 'BOTH'}</td>
        <td>${o.type}</td>
        <td>${px}</td>
        <td>${stopStr}</td>
        <td>${o.origQty}</td>
        <td>${o.executedQty}</td>
        <td>${o.reduceOnly ? 'Y' : '—'}</td>
        <td>${o.status}</td>
        <td><button type="button" class="binance-percentage-btn" onclick="showCancelOrderModal(${oid}, ${symJs})">Cancel</button></td>
      </tr>`;
    }).join('');
  } catch (e) {
    console.error('[FUTURES] Open orders', e);
  }
}

async function loadFutOrderHistory() {
  if (!AUTH?.token) return;
  const tbody = document.getElementById('fut-order-history-tbody');
  if (!tbody) return;
  try {
    const r = await fetch(API + '/binance/order-history?symbol=' + encodeURIComponent(currentFutPair) + '&limit=50', {
      headers: { Authorization: 'Bearer ' + AUTH.token }
    });
    const data = await r.json();
    if (!r.ok) {
      const msg = data.error || data._error || 'Veri alınamadı';
      tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;padding:40px;color:var(--binance-red)">${msg}</td></tr>`;
      return;
    }
    if (data._error && !(data.orders && data.orders.length)) {
      tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;padding:40px;color:var(--binance-red)">${data._error}</td></tr>`;
      return;
    }
    const orders = data.orders || [];
    if (orders.length === 0) {
      tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;padding:40px;color:var(--binance-text-secondary)">Bu sembol için emir geçmişi yok</td></tr>';
      return;
    }
    tbody.innerHTML = orders.map(o => {
      const stopStr = o.stopPrice != null && !isNaN(Number(o.stopPrice)) ? Number(o.stopPrice).toFixed(2) : '—';
      const avgStr = o.avgPrice != null && Number(o.avgPrice) > 0 ? Number(o.avgPrice).toFixed(2) : '—';
      const pxStr = o.price != null && Number(o.price) > 0 ? Number(o.price).toFixed(2) : '—';
      return `<tr>
        <td>${o.symbol}</td>
        <td class="${o.side === 'BUY' ? 'fut-cell-long' : 'fut-cell-short'}">${o.side}</td>
        <td>${o.positionSide || 'BOTH'}</td>
        <td>${o.type}</td>
        <td>${pxStr}</td>
        <td>${avgStr}</td>
        <td>${stopStr}</td>
        <td>${o.origQty}</td>
        <td>${o.executedQty}</td>
        <td>${o.status}</td>
        <td>${futFmtTime(o.time)}</td>
      </tr>`;
    }).join('');
  } catch (e) {
    console.error('[FUTURES] Order history', e);
  }
}

async function loadFutTradeHistory() {
  if (!AUTH?.token) return;
  const tbody = document.getElementById('fut-trade-history-tbody');
  if (!tbody) return;
  try {
    const r = await fetch(API + '/binance/trades?symbol=' + encodeURIComponent(currentFutPair) + '&limit=50', {
      headers: { Authorization: 'Bearer ' + AUTH.token }
    });
    const data = await r.json();
    if (!r.ok) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--binance-red)">${data.error || data._error || 'Veri alınamadı'}</td></tr>`;
      return;
    }
    if (data._error && !(data.trades && data.trades.length)) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--binance-red)">${data._error}</td></tr>`;
      return;
    }
    const trades = data.trades || [];
    if (trades.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--binance-text-secondary)">Bu sembol için işlem yok</td></tr>';
      return;
    }
    tbody.innerHTML = trades.map(t => {
      const pnl = Number(t.realizedPnl || 0);
      const pnlClass = pnl >= 0 ? 'fut-pnl-green' : 'fut-pnl-red';
      return `<tr>
        <td>${t.symbol}</td>
        <td class="${t.side === 'BUY' ? 'fut-cell-long' : 'fut-cell-short'}">${t.side}</td>
        <td>${t.positionSide || 'BOTH'}</td>
        <td>${Number(t.price).toFixed(2)}</td>
        <td>${t.qty}</td>
        <td class="${pnlClass}">${pnl.toFixed(4)}</td>
        <td>${typeof t.commission === 'number' ? t.commission.toFixed(4) : t.commission} USDT</td>
        <td>${futFmtTime(t.time)}</td>
      </tr>`;
    }).join('');
  } catch (e) {
    console.error('[FUTURES] Trade history', e);
  }
}

async function loadFutAssets() {
  if (!AUTH?.token) return;
  const tbody = document.getElementById('fut-assets-tbody');
  if (!tbody) return;
  try {
    const r = await fetch(API + '/binance/balances', { headers: { Authorization: 'Bearer ' + AUTH.token } });
    const data = await r.json();
    if (!r.ok) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--binance-red)">${data.error || 'Bakiye alınamadı'}</td></tr>`;
      return;
    }
    const balances = data.balances || [];
    if (balances.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--binance-text-secondary)">Bakiye yok veya API not connected</td></tr>';
      return;
    }
    tbody.innerHTML = balances.map(b => `<tr>
      <td>${b.asset}</td>
      <td>${Number(b.balance).toFixed(8)}</td>
      <td>${Number(b.availableBalance).toFixed(8)}</td>
      <td>${Number(b.crossWalletBalance).toFixed(8)}</td>
      <td>${Number(b.crossUnPnl).toFixed(8)}</td>
    </tr>`).join('');
  } catch (e) {
    console.error('[FUTURES] Assets', e);
  }
}

function refreshFuturesViewsAfterAction() {
  loadFutPositions();
  loadFutOpenOrders();
  loadFutOrderHistory();
  loadFutTradeHistory();
  loadFutAccountInfo();

  setTimeout(() => {
    loadFutPositions();
    loadFutOpenOrders();
    loadFutOrderHistory();
    loadFutTradeHistory();
    loadFutAccountInfo();
  }, 1200);
}

let _pendingCancelOrderId = null;
let _pendingCancelSymbol = null;
let _pendingCloseAllPositions = [];

function showCancelOrderModal(orderId, symbol) {
  _pendingCancelOrderId = String(orderId);
  _pendingCancelSymbol = symbol;
  const modal = document.getElementById('fut-cancel-order-modal');
  const btn = document.getElementById('fut-cancel-order-confirm');
  if (modal) modal.classList.add('open');
  if (btn) {
    btn.onclick = () => { closeFutCancelModal(); doCancelFutOrder(); };
  }
}

function closeFutCancelModal() {
  document.getElementById('fut-cancel-order-modal')?.classList.remove('open');
}

async function doCancelFutOrder() {
  if (!_pendingCancelOrderId || !_pendingCancelSymbol) return;
  const orderId = String(_pendingCancelOrderId);
  const symbol = _pendingCancelSymbol;
  _pendingCancelOrderId = _pendingCancelSymbol = null;
  try {
    const r = await fetch(API + '/binance/order/' + orderId + '?symbol=' + encodeURIComponent(symbol), {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + AUTH.token }
    });
    const data = await r.json();
    if (r.ok) {
      showNotification('Order cancelled', 'success');
      refreshFuturesViewsAfterAction();
    } else {
      showNotification(formatBinanceError(data.error) || 'Cancel başarısız', 'error');
    }
  } catch (e) {
    showNotification('Connection error', 'error');
  }
}

function showClosePositionModal(posIndex) {
  const cache = window._futPositionsCache;
  if (!cache || !cache[posIndex]) return;
  const pos = cache[posIndex];
  const pnl = parseFloat(pos.unrealizedProfit || 0);
  const posSide = pos.positionSide || (parseFloat(pos.positionAmt) > 0 ? 'LONG' : 'SHORT');
  const amt = parseFloat(pos.positionAmt);
  const entryPrice = parseFloat(pos.entryPrice || 0).toFixed(2);
  const markPrice = parseFloat(pos.markPrice || pos.lastPrice || 0).toFixed(2);
  const liqPrice = parseFloat(pos.liquidationPrice || 0).toFixed(2);
  const marginRatioPct = (parseFloat(pos.marginRatio || 0) * 100).toFixed(2);
  const marginVal = parseFloat(pos.initialMargin || pos.isolatedMargin || 0).toFixed(2);
  const roe = parseFloat(pos.roe || 0).toFixed(2);
  const lev = pos.leverage || 1;
  
  const pnlClass = pnl >= 0 ? 'pnl-positive' : 'pnl-negative';
  const pnlSign = pnl >= 0 ? '+' : '';
  
  const html = `
    <div class="fut-close-details-grid">
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Sembol</span><span class="fut-close-detail-value">${pos.symbol}</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Yön</span><span class="fut-close-detail-value ${posSide === 'LONG' ? 'fut-cell-long' : 'fut-cell-short'}">${posSide}</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Pozisyon</span><span class="fut-close-detail-value">${amt}</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Kaldıraç</span><span class="fut-close-detail-value">${lev}x</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Entry Price</span><span class="fut-close-detail-value">${entryPrice} USDT</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Mark Price</span><span class="fut-close-detail-value">${markPrice} USDT</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Liq. Price</span><span class="fut-close-detail-value">${liqPrice} USDT</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Margin</span><span class="fut-close-detail-value">${marginVal} USDT</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">Margin Ratio</span><span class="fut-close-detail-value">${marginRatioPct}%</span></div>
      <div class="fut-close-detail-row"><span class="fut-close-detail-label">ROE</span><span class="fut-close-detail-value">${roe}%</span></div>
      <div class="fut-close-detail-row" style="grid-column:1/-1;margin-top:8px;padding-top:12px;border-top:1px solid var(--binance-border)">
        <span class="fut-close-detail-label">Bekleyen PnL</span>
        <span class="fut-close-detail-value ${pnlClass}">${pnlSign}${pnl.toFixed(2)} USDT</span>
      </div>
    </div>
    <p style="margin-top:16px;font-size:12px;color:var(--binance-text-secondary)">Bu pozisyonu kapatmak istediğinizden emin misiniz?</p>
  `;
  
  const detailsEl = document.getElementById('fut-close-position-details');
  if (detailsEl) detailsEl.innerHTML = html;
  
  const modal = document.getElementById('fut-close-position-modal');
  const btn = document.getElementById('fut-close-position-confirm');
  if (modal) modal.classList.add('open');
  if (btn) {
    btn.onclick = () => {
      closeFutCloseModal();
      doCloseFutPosition(pos.symbol, posSide, amt);
    };
  }
}

function closeFutCloseModal() {
  document.getElementById('fut-close-position-modal')?.classList.remove('open');
}

async function doCloseFutPosition(symbol, positionSide, positionAmt) {
  const amt = parseFloat(positionAmt);
  if (!symbol || !amt) {
    showNotification('Geçersiz pozisyon', 'error');
    return;
  }
  
  try {
    const closeBody = { symbol };
    if (positionSide === 'LONG' || positionSide === 'SHORT' || positionSide === 'BOTH') {
      closeBody.positionSide = positionSide;
    }
    const response = await fetch(API + '/binance/close-position', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + AUTH.token
      },
      body: JSON.stringify(closeBody)
    });
    
    const data = await response.json();
    
    if (response.ok) {
      showNotification('Position closed', 'success');
      refreshFuturesViewsAfterAction();
    } else {
      showNotification('Pozisyon kapatılamadı: ' + formatBinanceError(data.error), 'error');
    }
  } catch (e) {
    console.error('Close position error:', e);
    showNotification('Connection error', 'error');
  }
}

function showCloseAllFutPositionsModal() {
  if (!AUTH?.token) {
    showNotification('Please log in', 'error');
    return;
  }

  const positions = (Array.isArray(window._futPositionsCache) ? window._futPositionsCache : [])
    .filter(pos => parseFloat(pos.positionAmt || 0) !== 0);
  if (!positions.length) {
    showNotification('Kapatilacak acik pozisyon yok', 'info');
    return;
  }

  _pendingCloseAllPositions = positions;

  const totalPnl = positions.reduce((sum, pos) => sum + parseFloat(pos.unrealizedProfit || 0), 0);
  const pnlClass = totalPnl >= 0 ? 'pnl-positive' : 'pnl-negative';
  const pnlSign = totalPnl >= 0 ? '+' : '';
  const symbols = positions.map(pos => `${pos.symbol} (${pos.positionSide || (parseFloat(pos.positionAmt || 0) > 0 ? 'LONG' : 'SHORT')})`);

  const detailsEl = document.getElementById('fut-close-all-positions-details');
  if (detailsEl) {
    detailsEl.innerHTML = `
      <div class="fut-close-details-grid">
        <div class="fut-close-detail-row"><span class="fut-close-detail-label">Pozisyon sayisi</span><span class="fut-close-detail-value">${positions.length}</span></div>
        <div class="fut-close-detail-row"><span class="fut-close-detail-label">Toplam bekleyen PnL</span><span class="fut-close-detail-value ${pnlClass}">${pnlSign}${Math.abs(totalPnl).toFixed(2)} USDT</span></div>
        <div class="fut-close-detail-row" style="grid-column:1/-1">
          <span class="fut-close-detail-label">Kapatilacak pozisyonlar</span>
          <span class="fut-close-detail-value" style="text-align:right;max-width:100%;white-space:normal;line-height:1.6">${symbols.join(', ')}</span>
        </div>
      </div>
      <p style="margin-top:16px;font-size:12px;color:var(--binance-text-secondary)">Tum acik pozisyonlar market emriyle tek seferde kapatilacak.</p>
    `;
  }

  const modal = document.getElementById('fut-close-all-positions-modal');
  const btn = document.getElementById('fut-close-all-positions-confirm');
  if (modal) modal.classList.add('open');
  if (btn) {
    btn.onclick = () => {
      closeFutCloseAllModal();
      doCloseAllFutPositions();
    };
  }
}

function closeFutCloseAllModal() {
  document.getElementById('fut-close-all-positions-modal')?.classList.remove('open');
}

async function doCloseAllFutPositions() {
  const positions = Array.isArray(_pendingCloseAllPositions) ? _pendingCloseAllPositions : [];
  _pendingCloseAllPositions = [];
  if (!positions.length) {
    showNotification('Kapatilacak acik pozisyon yok', 'info');
    return;
  }

  try {
    const response = await fetch(API + '/binance/close-all-positions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + AUTH.token
      }
    });

    const data = await response.json();
    if (response.ok || response.status === 207) {
      if (data.failed && data.failed.length) {
        showNotification(`${data.closed?.length || 0} pozisyon kapatildi, ${data.failed.length} pozisyon kaldi`, 'error');
      } else {
        showNotification(`${data.closed?.length || 0} pozisyon kapatildi`, 'success');
      }
      refreshFuturesViewsAfterAction();
    } else {
      showNotification(formatBinanceError(data.error) || 'Tum pozisyonlar kapatilamadi', 'error');
    }
  } catch (e) {
    console.error('Close all positions error:', e);
    showNotification('Connection error', 'error');
  }
}

function closeAllFutPositions() {
  showCloseAllFutPositionsModal();
}

// Switch Bottom Tab
function switchFutBottomTab(tab) {
  document.querySelectorAll('.binance-orders-table').forEach(t => { t.style.display = 'none'; });
  if (tab === 'positions') {
    const pt = document.getElementById('fut-positions-table');
    if (pt) pt.style.display = 'table';
    loadFutPositions();
  }
  if (tab === 'open-orders') {
    const ot = document.getElementById('fut-open-orders-table');
    if (ot) ot.style.display = 'table';
    loadFutOpenOrders();
  }
  if (tab === 'order-history') {
    const ht = document.getElementById('fut-order-history-table');
    if (ht) ht.style.display = 'table';
    loadFutOrderHistory();
  }
  if (tab === 'trade-history') {
    const tt = document.getElementById('fut-trade-history-table');
    if (tt) tt.style.display = 'table';
    loadFutTradeHistory();
  }
  if (tab === 'assets') {
    const at = document.getElementById('fut-assets-table');
    if (at) at.style.display = 'table';
    loadFutAssets();
  }
  const order = ['positions', 'open-orders', 'order-history', 'trade-history', 'assets'];
  const idx = order.indexOf(tab);
  document.querySelectorAll('.binance-bottom-tab').forEach((el, i) => {
    el.classList.toggle('active', idx === i);
  });
  updateFutBottomPanelTitle(tab);
}

// Make functions globally available
window.updateFutLongCost = updateFutLongCost;
window.updateFutShortCost = updateFutShortCost;
window.setFutLongPercentage = setFutLongPercentage;
window.setFutShortPercentage = setFutShortPercentage;
window.loadFutPositions = loadFutPositions;
window.loadFutOpenOrders = loadFutOpenOrders;
window.showCancelOrderModal = showCancelOrderModal;
window.showClosePositionModal = showClosePositionModal;
window.showCloseAllFutPositionsModal = showCloseAllFutPositionsModal;
window.closeFutCancelModal = closeFutCancelModal;
window.closeFutCloseModal = closeFutCloseModal;
window.closeFutCloseAllModal = closeFutCloseAllModal;
window.switchFutBottomTab = switchFutBottomTab;
window.closeAllFutPositions = closeAllFutPositions;

console.log('[FUTURES] Trading functions loaded');


// ═══════════════════════════════════════
// MARGIN MODE MODAL
// ═══════════════════════════════════════

let currentMarginMode = 'CROSSED';

function openMarginModal() {
  const modal = document.getElementById('margin-modal');
  if (modal) {
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
    selectMarginMode(currentMarginMode, false);
  }
}

function closeMarginModal() {
  const modal = document.getElementById('margin-modal');
  if (modal) modal.classList.remove('open');
  document.body.style.overflow = '';
}

function selectMarginMode(mode, updateGlobal = true) {
  if (updateGlobal) currentMarginMode = mode;
  
  const btnCross = document.getElementById('btn-margin-cross');
  const btnIso = document.getElementById('btn-margin-isolated');
  const descCross = document.getElementById('margin-mode-desc-cross');
  const descIso = document.getElementById('margin-mode-desc-isolated');
  
  if (mode === 'CROSSED') {
    if (btnCross) {
      btnCross.classList.add('active');
      btnCross.style.background = '#ffffff';
      btnCross.style.color = '#000000';
    }
    if (btnIso) {
      btnIso.classList.remove('active');
      btnIso.style.background = 'transparent';
      btnIso.style.color = '#888888';
    }
    if (descCross) descCross.style.display = 'block';
    if (descIso) descIso.style.display = 'none';
  } else {
    if (btnIso) {
      btnIso.classList.add('active');
      btnIso.style.background = '#ffffff';
      btnIso.style.color = '#000000';
    }
    if (btnCross) {
      btnCross.classList.remove('active');
      btnCross.style.background = 'transparent';
      btnCross.style.color = '#888888';
    }
    if (descIso) descIso.style.display = 'block';
    if (descCross) descCross.style.display = 'none';
  }
}

async function confirmMarginMode() {
  if (!AUTH?.token) return;
  const symbol = currentFutPair || 'BTCUSDT';
  const mode = currentMarginMode;
  
  try {
    const res = await fetch(API + '/trading/futures/margin-type', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + AUTH.token
      },
      body: JSON.stringify({ symbol: symbol, marginType: mode })
    });
    
    const data = await res.json();
    
    if (res.ok) {
      const displayEl = document.getElementById('fut-margin-type-display');
      if (displayEl) {
        displayEl.textContent = mode === 'CROSSED' ? 'Cross' : 'Isolated';
      }
      document.querySelectorAll('.fut-margin-type-display-form').forEach(el => {
        el.textContent = mode === 'CROSSED' ? 'Cross' : 'Isolated';
      });
      if (typeof showToast === 'function') {
        showToast('success', `Margin mode changed to ${mode === 'CROSSED' ? 'Cross' : 'Isolated'}`);
      } else {
        showNotification(`Margin mode changed to ${mode === 'CROSSED' ? 'Cross' : 'Isolated'}`, 'success');
      }
      closeMarginModal();
    } else {
      const errMsg = data.error || data.message || 'Margin mode change failed';
      if (typeof showToast === 'function') {
        if (errMsg.includes('zaten') || errMsg.includes('already')) {
          showToast('success', errMsg);
          const displayEl = document.getElementById('fut-margin-type-display');
          if (displayEl) displayEl.textContent = mode === 'CROSSED' ? 'Cross' : 'Isolated';
          document.querySelectorAll('.fut-margin-type-display-form').forEach(el => {
            el.textContent = mode === 'CROSSED' ? 'Cross' : 'Isolated';
          });
          closeMarginModal();
        } else {
          showToast('error', errMsg);
        }
      } else {
        showNotification(errMsg, 'error');
      }
    }
  } catch (err) {
    if (typeof showToast === 'function') showToast('error', 'Connection error');
  }
}

window.openMarginModal = openMarginModal;
window.closeMarginModal = closeMarginModal;
window.selectMarginMode = selectMarginMode;
window.confirmMarginMode = confirmMarginMode;


// ═══════════════════════════════════════
// LEVERAGE MODAL
// ═══════════════════════════════════════

let currentLeverageType = 'long'; // 'long', 'short' veya 'both'
let tempLeverage = 10;
let currentAvailableBalance = 0; // Max hesaplaması için kullanılır

function openLeverageModal(type) {
  currentLeverageType = type;
  
  // Mevcut kaldıraç değerini oku: long/short/both için ilgili span'dan
  let currentLeverage = 10;
  if (type === 'long') {
    const el = document.getElementById('fut-long-leverage-value');
    currentLeverage = el ? parseFutLeverage(el.textContent) : parseInt(localStorage.getItem('fut-long-leverage')) || 10;
  } else if (type === 'short') {
    const el = document.getElementById('fut-short-leverage-value');
    currentLeverage = el ? parseFutLeverage(el.textContent) : parseInt(localStorage.getItem('fut-short-leverage')) || 10;
  } else {
    const longEl = document.getElementById('fut-long-leverage-value');
    currentLeverage = longEl ? parseFutLeverage(longEl.textContent) : parseInt(localStorage.getItem('fut-long-leverage')) || 10;
  }
  
  tempLeverage = Math.max(1, Math.min(125, currentLeverage));
  const slider = document.getElementById('modal-leverage-slider');
  if (slider) {
    slider.value = tempLeverage;
    slider.setAttribute('value', tempLeverage);
  }
  const valEl = document.getElementById('modal-leverage-value');
  if (valEl) valEl.textContent = tempLeverage + 'x';
  updateMaxPosition();
  
  document.getElementById('leverage-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeLeverageModal() {
  document.getElementById('leverage-modal').classList.remove('open');
  document.body.style.overflow = '';
}

function updateModalLeverage(value) {
  tempLeverage = Math.max(1, Math.min(125, parseInt(value) || 10));
  const slider = document.getElementById('modal-leverage-slider');
  if (slider) slider.value = tempLeverage;
  const valEl = document.getElementById('modal-leverage-value');
  if (valEl) valEl.textContent = tempLeverage + 'x';
  updateMaxPosition();
}

function increaseLeverage() {
  if (tempLeverage < 125) {
    tempLeverage++;
    document.getElementById('modal-leverage-slider').value = tempLeverage;
    document.getElementById('modal-leverage-value').textContent = tempLeverage + 'x';
    updateMaxPosition();
  }
}

function decreaseLeverage() {
  if (tempLeverage > 1) {
    tempLeverage--;
    document.getElementById('modal-leverage-slider').value = tempLeverage;
    document.getElementById('modal-leverage-value').textContent = tempLeverage + 'x';
    updateMaxPosition();
  }
}

function updateMaxPosition() {
  const bal = currentAvailableBalance > 0 ? currentAvailableBalance : currentBalance;
  const maxPosition = (bal * tempLeverage).toLocaleString('en-US', {minimumFractionDigits:0, maximumFractionDigits:0});
  const el = document.getElementById('modal-max-position');
  if (el) el.textContent = maxPosition + ' USDT';
}

function confirmLeverage() {
  const lev = tempLeverage;
  
  // Long ve/veya Short kaldıraç değerlerini güncelle
  if (currentLeverageType === 'long' || currentLeverageType === 'both') {
    const longEl = document.getElementById('fut-long-leverage-value');
    if (longEl) longEl.textContent = lev + 'x';
    localStorage.setItem('fut-long-leverage', lev);
  }
  if (currentLeverageType === 'short' || currentLeverageType === 'both') {
    const shortEl = document.getElementById('fut-short-leverage-value');
    if (shortEl) shortEl.textContent = lev + 'x';
    localStorage.setItem('fut-short-leverage', lev);
  }
  localStorage.setItem('fut-leverage', lev);
  
  // Header'daki kaldıraç gösterimini güncelle
  const displayEl = document.getElementById('fut-leverage-display');
  if (displayEl) displayEl.textContent = lev + 'x';
  
  // Cost/max hesaplamalarını yenile
  updateFutLongCost();
  updateFutShortCost();
  
  closeLeverageModal();
  
  const msg = `Kaldıraç ${lev}x olarak ayarlandı`;
  if (typeof showNotification === 'function') {
    showNotification(msg, 'success');
  } else if (typeof showToast === 'function') {
    showToast('success', msg);
  }
}

/** Sembolden base asset çıkar (ETHUSDT->ETH, BTCUSDT->BTC) */
function getFutBaseAsset() {
  const s = (currentFutPair || 'ETHUSDT').toUpperCase();
  if (s.endsWith('USDT')) return s.slice(0, -4);
  if (s.endsWith('BUSD')) return s.slice(0, -4);
  return 'ETH';
}

// Update cost functions - liq price size slider ile birlikte güncellenir
function updateFutLongCost() {
  const priceEl = document.getElementById('fut-long-price');
  const sizeEl = document.getElementById('fut-long-size');
  const levEl = document.getElementById('fut-long-leverage-value');
  const currentPriceEl = document.getElementById('fut-current-price');
  let price = parseFloat(priceEl?.value) || 0;
  if (price <= 0 && currentPriceEl?.textContent) {
    price = parseFloat(String(currentPriceEl.textContent).replace(/[^0-9.]/g, '')) || 0;
  }
  const size = parseFloat(sizeEl?.value) || 0;
  const leverage = parseFutLeverage(levEl?.textContent);
  const bal = currentAvailableBalance > 0 ? currentAvailableBalance : currentBalance;
  
  const cost = price > 0 && size > 0 ? (price * size) / leverage : 0;
  const max = price > 0 ? (bal * leverage) / price : 0;
  
  const baseAsset = getFutBaseAsset();
  const costEl = document.getElementById('fut-long-cost');
  const maxEl = document.getElementById('fut-long-max');
  const liqEl = document.getElementById('fut-long-liq-price');
  if (costEl) costEl.textContent = cost.toFixed(2) + ' USDT';
  if (maxEl) maxEl.textContent = (max || 0).toFixed(3) + ' ' + baseAsset;
  
  if (price > 0 && size > 0 && leverage > 0 && liqEl) {
    const mmr = 0.004;
    const liqPrice = price * (1 - (1 / leverage) + mmr);
    liqEl.textContent = liqPrice.toFixed(2);
  } else if (liqEl) {
    liqEl.textContent = '—';
  }
}

function updateFutShortCost() {
  const priceEl = document.getElementById('fut-short-price');
  const sizeEl = document.getElementById('fut-short-size');
  const levEl = document.getElementById('fut-short-leverage-value');
  const currentPriceEl = document.getElementById('fut-current-price');
  let price = parseFloat(priceEl?.value) || 0;
  if (price <= 0 && currentPriceEl?.textContent) {
    price = parseFloat(String(currentPriceEl.textContent).replace(/[^0-9.]/g, '')) || 0;
  }
  const size = parseFloat(sizeEl?.value) || 0;
  const leverage = parseFutLeverage(levEl?.textContent);
  const bal = currentAvailableBalance > 0 ? currentAvailableBalance : currentBalance;
  
  const cost = price > 0 && size > 0 ? (price * size) / leverage : 0;
  const max = price > 0 ? (bal * leverage) / price : 0;
  
  const baseAsset = getFutBaseAsset();
  const costEl = document.getElementById('fut-short-cost');
  const maxEl = document.getElementById('fut-short-max');
  const liqEl = document.getElementById('fut-short-liq-price');
  if (costEl) costEl.textContent = cost.toFixed(2) + ' USDT';
  if (maxEl) maxEl.textContent = (max || 0).toFixed(3) + ' ' + baseAsset;
  
  if (price > 0 && size > 0 && leverage > 0 && liqEl) {
    const mmr = 0.004;
    const liqPrice = price * (1 + (1 / leverage) - mmr);
    liqEl.textContent = liqPrice.toFixed(2);
  } else if (liqEl) {
    liqEl.textContent = '—';
  }
}

function setFutLongPercentage(percent) {
  const leverage = parseInt(document.getElementById('fut-long-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-long-price').value) || 0;
  
  if (!price) {
    showNotification('Enter price first', 'error');
    return;
  }
  
  const margin = currentBalance * (percent / 100);
  const size = (margin * leverage) / price;
  
  document.getElementById('fut-long-size').value = size.toFixed(3);
  
  // Update slider
  const slider = document.getElementById('fut-long-size-slider');
  slider.value = percent;
  slider.style.setProperty('--slider-progress', percent + '%');
  
  updateFutLongCost();
}

function setFutShortPercentage(percent) {
  const leverage = parseInt(document.getElementById('fut-short-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-short-price').value) || 0;
  
  if (!price) {
    showNotification('Enter price first', 'error');
    return;
  }
  
  const margin = currentBalance * (percent / 100);
  const size = (margin * leverage) / price;
  
  document.getElementById('fut-short-size').value = size.toFixed(3);
  
  // Update slider
  const slider = document.getElementById('fut-short-size-slider');
  slider.value = percent;
  slider.style.setProperty('--slider-progress', percent + '%');
  
  updateFutShortCost();
}

// Make modal and account functions globally available
window.openLeverageModal = openLeverageModal;
window.closeLeverageModal = closeLeverageModal;
window.toggleFutSingleAssetMode = toggleFutSingleAssetMode;
window.updateModalLeverage = updateModalLeverage;
window.increaseLeverage = increaseLeverage;
window.decreaseLeverage = decreaseLeverage;
window.confirmLeverage = confirmLeverage;

console.log('[FUTURES] Leverage modal loaded');


// ═══════════════════════════════════════
// SIZE SLIDER FUNCTIONS
// ═══════════════════════════════════════

// Update Long Size from Slider
function updateLongSizeFromSlider(percent) {
  const leverage = parseInt(document.getElementById('fut-long-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-long-price').value) || 0;
  
  if (!price) return;
  
  // Calculate max size based on balance and leverage
  const maxSize = (currentBalance * leverage) / price;
  
  // Calculate size based on percentage
  const size = (maxSize * percent) / 100;
  
  document.getElementById('fut-long-size').value = size.toFixed(3);
  
  // Update slider progress
  const slider = document.getElementById('fut-long-size-slider');
  slider.style.setProperty('--slider-progress', percent + '%');
  
  updateFutLongCost();
}

// Update Long Slider from Size Input
function updateLongSizeSlider() {
  const leverage = parseInt(document.getElementById('fut-long-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-long-price').value) || 0;
  const size = parseFloat(document.getElementById('fut-long-size').value) || 0;
  
  if (!price) return;
  
  const maxSize = (currentBalance * leverage) / price;
  const percent = maxSize > 0 ? (size / maxSize) * 100 : 0;
  
  const slider = document.getElementById('fut-long-size-slider');
  slider.value = Math.min(100, Math.max(0, percent));
  slider.style.setProperty('--slider-progress', slider.value + '%');
}

// Update Short Size from Slider
function updateShortSizeFromSlider(percent) {
  const leverage = parseInt(document.getElementById('fut-short-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-short-price').value) || 0;
  
  if (!price) return;
  
  // Calculate max size based on balance and leverage
  const maxSize = (currentBalance * leverage) / price;
  
  // Calculate size based on percentage
  const size = (maxSize * percent) / 100;
  
  document.getElementById('fut-short-size').value = size.toFixed(3);
  
  // Update slider progress
  const slider = document.getElementById('fut-short-size-slider');
  slider.style.setProperty('--slider-progress', percent + '%');
  
  updateFutShortCost();
}

// Update Short Slider from Size Input
function updateShortSizeSlider() {
  const leverage = parseInt(document.getElementById('fut-short-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-short-price').value) || 0;
  const size = parseFloat(document.getElementById('fut-short-size').value) || 0;
  
  if (!price) return;
  
  const maxSize = (currentBalance * leverage) / price;
  const percent = maxSize > 0 ? (size / maxSize) * 100 : 0;
  
  const slider = document.getElementById('fut-short-size-slider');
  slider.value = Math.min(100, Math.max(0, percent));
  slider.style.setProperty('--slider-progress', slider.value + '%');
}

// Make functions globally available
window.updateLongSizeFromSlider = updateLongSizeFromSlider;
window.updateLongSizeSlider = updateLongSizeSlider;
window.updateShortSizeFromSlider = updateShortSizeFromSlider;
window.updateShortSizeSlider = updateShortSizeSlider;

console.log('[FUTURES] Size slider functions loaded');


// ═══════════════════════════════════════
// SIZE TOOLTIP FUNCTIONS
// ═══════════════════════════════════════

function showSizeTooltip(type) {
  const tooltipId = type === 'long' ? 'fut-long-size-tooltip' : 'fut-short-size-tooltip';
  const tooltip = document.getElementById(tooltipId);
  if (tooltip) {
    tooltip.classList.add('show');
  }
}

function hideSizeTooltip(type) {
  const tooltipId = type === 'long' ? 'fut-long-size-tooltip' : 'fut-short-size-tooltip';
  const tooltip = document.getElementById(tooltipId);
  if (tooltip) {
    tooltip.classList.remove('show');
  }
}

function updateSizeTooltipPosition(type, value) {
  const tooltipId = type === 'long' ? 'fut-long-size-tooltip' : 'fut-short-size-tooltip';
  const sliderId = type === 'long' ? 'fut-long-size-slider' : 'fut-short-size-slider';
  
  const tooltip = document.getElementById(tooltipId);
  const slider = document.getElementById(sliderId);
  
  if (!tooltip || !slider) return;
  
  // Update tooltip text
  tooltip.textContent = parseFloat(value).toFixed(1) + '%';
  
  // Calculate position
  const sliderWidth = slider.offsetWidth;
  const thumbWidth = 16; // Width of the thumb
  const percent = value / 100;
  const position = (sliderWidth - thumbWidth) * percent + (thumbWidth / 2);
  
  tooltip.style.left = position + 'px';
}

// Update existing slider functions to also update tooltip
function updateLongSizeFromSlider(percent) {
  const leverage = parseInt(document.getElementById('fut-long-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-long-price').value) || 0;
  
  if (!price) return;
  
  const maxSize = (currentBalance * leverage) / price;
  const size = (maxSize * percent) / 100;
  
  document.getElementById('fut-long-size').value = size.toFixed(3);
  
  const slider = document.getElementById('fut-long-size-slider');
  slider.style.setProperty('--slider-progress', percent + '%');
  
  updateSizeTooltipPosition('long', percent);
  updateFutLongCost();
}

function updateShortSizeFromSlider(percent) {
  const leverage = parseInt(document.getElementById('fut-short-leverage-value').textContent) || 10;
  const price = parseFloat(document.getElementById('fut-short-price').value) || 0;
  
  if (!price) return;
  
  const maxSize = (currentBalance * leverage) / price;
  const size = (maxSize * percent) / 100;
  
  document.getElementById('fut-short-size').value = size.toFixed(3);
  
  const slider = document.getElementById('fut-short-size-slider');
  slider.style.setProperty('--slider-progress', percent + '%');
  
  updateSizeTooltipPosition('short', percent);
  updateFutShortCost();
}

// Make functions globally available
window.showSizeTooltip = showSizeTooltip;
window.hideSizeTooltip = hideSizeTooltip;
window.updateSizeTooltipPosition = updateSizeTooltipPosition;

console.log('[FUTURES] Size tooltip functions loaded');


// ═══════════════════════════════════════
// ORDER TYPE SWITCHING
// ═══════════════════════════════════════

let currentLongOrderType = 'limit';
let currentShortOrderType = 'limit';

function switchLongOrderType(type) {
  currentLongOrderType = type;
  
  // Update active tab
  const tabs = document.querySelectorAll('.binance-trade-form:first-child .binance-trade-tab');
  tabs.forEach((tab, index) => {
    tab.classList.remove('active');
    if ((index === 0 && type === 'limit') || (index === 1 && type === 'market') || (index === 2 && type === 'stop-limit')) {
      tab.classList.add('active');
    }
  });
  
  // Show/hide inputs based on order type
  const priceGroup = document.getElementById('fut-long-price-group');
  const stopPriceGroup = document.getElementById('fut-long-stop-price-group');
  
  if (type === 'market') {
    // Market order: hide price input
    if (priceGroup) priceGroup.style.display = 'none';
    if (stopPriceGroup) stopPriceGroup.style.display = 'none';
  } else if (type === 'stop-limit') {
    // Stop-Limit: show both stop price and limit price
    if (priceGroup) priceGroup.style.display = 'block';
    if (stopPriceGroup) stopPriceGroup.style.display = 'block';
  } else {
    // Limit order: show only price input
    if (priceGroup) priceGroup.style.display = 'block';
    if (stopPriceGroup) stopPriceGroup.style.display = 'none';
  }
}

function switchShortOrderType(type) {
  currentShortOrderType = type;
  
  // Update active tab
  const tabs = document.querySelectorAll('.binance-trade-form:last-child .binance-trade-tab');
  tabs.forEach((tab, index) => {
    tab.classList.remove('active');
    if ((index === 0 && type === 'limit') || (index === 1 && type === 'market') || (index === 2 && type === 'stop-limit')) {
      tab.classList.add('active');
    }
  });
  
  // Show/hide inputs based on order type
  const priceGroup = document.getElementById('fut-short-price-group');
  const stopPriceGroup = document.getElementById('fut-short-stop-price-group');
  
  if (type === 'market') {
    // Market order: hide price input
    if (priceGroup) priceGroup.style.display = 'none';
    if (stopPriceGroup) stopPriceGroup.style.display = 'none';
  } else if (type === 'stop-limit') {
    // Stop-Limit: show both stop price and limit price
    if (priceGroup) priceGroup.style.display = 'block';
    if (stopPriceGroup) stopPriceGroup.style.display = 'block';
  } else {
    // Limit order: show only price input
    if (priceGroup) priceGroup.style.display = 'block';
    if (stopPriceGroup) stopPriceGroup.style.display = 'none';
  }
}

// Update execute functions to handle different order types
async function executeFuturesLong() {
  const size = parseFloat(document.getElementById('fut-long-size').value);
  const levEl = document.getElementById('fut-long-leverage-value');
  const leverage = parseFutLeverage(levEl ? levEl.textContent : 10);
  
  if (!size) {
    showNotification('Enter quantity', 'error');
    return;
  }
  
  if (!AUTH || !AUTH.token) {
    showNotification('Please log in', 'error');
    return;
  }
  
  const rq = futuresRoundQtyBase(size);
  if (rq == null) {
    showNotification('Enter valid quantity (min 0.001 ETH)', 'error');
    return;
  }

  let orderData = {
    symbol: currentFutPair,
    side: 'BUY',
    quantity: rq,
    leverage: leverage
  };
  
  if (currentLongOrderType === 'market') {
    orderData.type = 'MARKET';
  } else if (currentLongOrderType === 'stop-limit') {
    const stopPrice = parseFloat(document.getElementById('fut-long-stop-price').value);
    const price = parseFloat(document.getElementById('fut-long-price').value);
    
    if (!stopPrice || !price) {
      showNotification('Enter stop price and limit price', 'error');
      return;
    }
    
    orderData.type = 'STOP';
    orderData.stopPrice = stopPrice;
    orderData.price = price;
    orderData.timeInForce = 'GTC';
  } else {
    // Limit order
    const price = parseFloat(document.getElementById('fut-long-price').value);
    
    if (!price) {
      showNotification('Enter price', 'error');
      return;
    }
    
    orderData.type = 'LIMIT';
    orderData.price = price;
    orderData.timeInForce = 'GTC';
  }
  
  const btn = document.querySelector('.binance-buy-btn');
  btn.disabled = true;
  btn.textContent = 'Processing...';
  
  try {
    futuresApplyHedgeToOpenOrder(orderData);
    const response = await binanceFuturesSendOrder(orderData.leverage, orderData);
    
    const data = await response.json();
    
    if (response.ok) {
      showNotification(`Long ${currentLongOrderType} order created!`, 'success');
      document.getElementById('fut-long-price').value = '';
      document.getElementById('fut-long-size').value = '';
      if (document.getElementById('fut-long-stop-price')) {
        document.getElementById('fut-long-stop-price').value = '';
      }
      updateFutLongCost();
      loadFutAccountInfo();
      loadFutPositions();
      loadFutOpenOrders();
      loadFutOrderHistory();
      loadFutTradeHistory();
    } else {
      const errorMsg = formatBinanceError(data.error);
      
      // Insufficient balance hatası için özel mesaj
      if (errorMsg.includes('Insufficient balance') || errorMsg.toLowerCase().includes('insufficient')) {
        showNotification('⚠️ Insufficient balance! Binance Testnet hesabınıza https://demo.binance.com adresinden giriş yapıp ücretsiz test USDT alın.', 'error');
      } else {
        showNotification('Could not open position: ' + errorMsg, 'error');
      }
    }
  } catch (e) {
    console.error('Long order error:', e);
    showNotification('Connection error', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Open Long';
  }
}

async function executeFuturesShort() {
  const size = parseFloat(document.getElementById('fut-short-size').value);
  const levEl = document.getElementById('fut-short-leverage-value');
  const leverage = parseFutLeverage(levEl ? levEl.textContent : 10);
  
  if (!size) {
    showNotification('Enter quantity', 'error');
    return;
  }
  
  if (!AUTH || !AUTH.token) {
    showNotification('Please log in', 'error');
    return;
  }

  const rq = futuresRoundQtyBase(size);
  if (rq == null) {
    showNotification('Enter valid quantity (min 0.001 ETH)', 'error');
    return;
  }
  
  let orderData = {
    symbol: currentFutPair,
    side: 'SELL',
    quantity: rq,
    leverage: leverage
  };
  
  if (currentShortOrderType === 'market') {
    orderData.type = 'MARKET';
  } else if (currentShortOrderType === 'stop-limit') {
    const stopPrice = parseFloat(document.getElementById('fut-short-stop-price').value);
    const price = parseFloat(document.getElementById('fut-short-price').value);
    
    if (!stopPrice || !price) {
      showNotification('Enter stop price and limit price', 'error');
      return;
    }
    
    orderData.type = 'STOP';
    orderData.stopPrice = stopPrice;
    orderData.price = price;
    orderData.timeInForce = 'GTC';
  } else {
    // Limit order
    const price = parseFloat(document.getElementById('fut-short-price').value);
    
    if (!price) {
      showNotification('Enter price', 'error');
      return;
    }
    
    orderData.type = 'LIMIT';
    orderData.price = price;
    orderData.timeInForce = 'GTC';
  }
  
  const btn = document.querySelector('.binance-sell-btn');
  btn.disabled = true;
  btn.textContent = 'Processing...';
  
  try {
    futuresApplyHedgeToOpenOrder(orderData);
    const response = await binanceFuturesSendOrder(orderData.leverage, orderData);
    
    const data = await response.json();
    
    if (response.ok) {
      showNotification(`Short ${currentShortOrderType} order created!`, 'success');
      document.getElementById('fut-short-price').value = '';
      document.getElementById('fut-short-size').value = '';
      if (document.getElementById('fut-short-stop-price')) {
        document.getElementById('fut-short-stop-price').value = '';
      }
      updateFutShortCost();
      loadFutAccountInfo();
      loadFutPositions();
      loadFutOpenOrders();
      loadFutOrderHistory();
      loadFutTradeHistory();
    } else {
      const errorMsg = formatBinanceError(data.error);
      
      // Insufficient balance hatası için özel mesaj
      if (errorMsg.includes('Insufficient balance') || errorMsg.toLowerCase().includes('insufficient')) {
        showNotification('⚠️ Insufficient balance! Binance Testnet hesabınıza https://demo.binance.com adresinden giriş yapıp ücretsiz test USDT alın.', 'error');
      } else {
        showNotification('Could not open position: ' + errorMsg, 'error');
      }
    }
  } catch (e) {
    console.error('Short order error:', e);
    showNotification('Connection error', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Open Short';
  }
}

// Make functions globally available
window.switchLongOrderType = switchLongOrderType;
window.switchShortOrderType = switchShortOrderType;
window.executeFuturesLong = executeFuturesLong;
window.executeFuturesShort = executeFuturesShort;

console.log('[FUTURES] Order type switching loaded');
