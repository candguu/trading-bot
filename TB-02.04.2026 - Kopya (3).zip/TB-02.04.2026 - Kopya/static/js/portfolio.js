/* ═══════════════════════════════════════
   PORTFOLIO MANAGEMENT - Binance Testnet Integration
═══════════════════════════════════════ */

let _portfolioTimer = null;
let _positionsTimer = null; // Pozisyonlar için ayrı timer
let _portfolioData = {
    balance: 0,
    assets: [],
    openOrders: [],
    openPositions: [],
    allTrades: [],
    trades: [],
    reportTrades: [],
    dailyPnL: 0,
    weeklyPnL: 0,
    monthlyPnL: 0,
    totalPnL: 0
};

let _pnlChart = null;
let _pnlSeries = null;
let _doughnutChart = null;

// ─── Load Portfolio Data ───
async function loadPortfolio() {
    if (!AUTH.token) {
        console.error('No auth token!');
        return;
    }

    console.log('Loading portfolio...');

    try {
        // Check API key status
        console.log('Checking API status...');
        const statusRes = await fetch(API + '/binance/api-keys', {
            headers: { 'Authorization': 'Bearer ' + AUTH.token }
        });
        const statusData = await statusRes.json();
        console.log('API Status:', statusData);

        if (!statusRes.ok || !statusData.configured) {
            console.warn('API not configured');
            _setApiNotConfigured();
            return;
        }

        // Load account data
        console.log('Loading account data...');
        const balRes = await fetch(API + '/binance/account', {
            headers: { 'Authorization': 'Bearer ' + AUTH.token }
        });
        const balData = await balRes.json();

        console.log('Account data:', balData); // Debug

        if (balRes.ok) {
            _portfolioData.balance = balData.totalWalletBalance || 0;
            _renderBalance(balData);
            _setApiConnected(true);
        } else {
            _setApiError(balData.error);
            console.error('Account error:', balData.error);
        }

        // Load open orders
        await loadOpenOrders();

        // Pozisyonlar için otomatik yenileme başlat (ayrı timer)
        startPositionsAutoRefresh();
        
        // Market verilerini otomatik güncellemeyi başlat
        if (typeof startMarketDataAutoRefresh === 'function') {
            startMarketDataAutoRefresh();
        }

        // Load trade history for multiple symbols
        await loadAllTrades();

        // Calculate statistics
        try {
            _calculateStatistics();
        } catch (statsError) {
            console.warn('Statistics calculation error:', statsError);
            // İstatistik hatası API hatasından farklı, API durumunu etkilemez
        }

    } catch (e) {
        console.warn('Portfolio load error:', e);
        _setApiError('Bağlantı hatası');
    }

    // Auto-refresh every 5 seconds for balance and orders
    if (_portfolioTimer) clearInterval(_portfolioTimer);
    _portfolioTimer = setInterval(async () => {
        if (document.getElementById('dash-portfolio')?.style.display !== 'none') {
            // Balance'ı yenile
            try {
                const balRes = await fetch(API + '/binance/account', {
                    headers: { 'Authorization': 'Bearer ' + AUTH.token }
                });
                const balData = await balRes.json();
                if (balRes.ok) {
                    _portfolioData.balance = balData.totalWalletBalance || 0;
                    _renderBalance(balData);
                    _setApiConnected(true);
                } else {
                    console.warn('Balance refresh failed:', balData.error);
                }
            } catch (e) {
                console.warn('Balance refresh error:', e);
            }
            
            // Orders'ı yenile
            loadOpenOrders();
        } else {
            clearInterval(_portfolioTimer);
            stopPositionsAutoRefresh();
            if (typeof stopMarketDataAutoRefresh === 'function') {
                stopMarketDataAutoRefresh();
            }
            _portfolioTimer = null;
        }
    }, 5000); // 5 saniyede bir
}

// ─── Render Balance ───
function _renderBalance(data) {
    console.log('Rendering balance with data:', data);

    const totalBalance = parseFloat(data.totalWalletBalance || 0);
    console.log('Total balance:', totalBalance);

    // Update top navigation balance
    const navBalanceEl = document.getElementById('nav-balance-val');
    if (navBalanceEl) {
        navBalanceEl.textContent = '$ ' + totalBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    let assets = data.assets || [];

    console.log('Assets to render:', assets.length);
    
    // Asset verilerini global state'e kaydet (market data güncellemesi için)
    _portfolioData.assets = assets;
    _portfolioData.balance = totalBalance;

    if (assets.length === 0) {
        const listEl = document.getElementById('pf-assets-list');
        if (listEl) {
            listEl.innerHTML = '<div style="padding:40px;text-align:center;color:rgba(255,255,255,0.3)">Veri yok</div>';
        }
        return;
    }

    const totalValue = totalBalance;

    // Render Pie Chart
    renderAssetsPieChart(assets, totalValue);

    // Render Asset List - her seferinde güncel market verileriyle
    renderAssetsList(assets, totalValue);

    console.log('Assets rendered successfully');
}


// ─── Load Positions (for ticker) ───
async function loadPositions(showLoading = true) {
    if (!AUTH.token) return;

    const content = document.getElementById('pf-positions-content');
    
    // Loading state sadece ilk yüklemede göster
    if (showLoading && content) {
        content.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);width:100%"><div class="spinner"></div> Pozisyonlar yükleniyor...</div>';
    }

    try {
        const startTime = performance.now();
        
        const res = await fetch(API + '/binance/positions', {
            headers: { 'Authorization': 'Bearer ' + AUTH.token }
        });
        const data = await res.json();

        const endTime = performance.now();
        console.log(`🔥 POSITIONS RESPONSE (${(endTime - startTime).toFixed(0)}ms):`, data);

        if (res.ok && data.positions) {
            console.log('🔥 RENDERING POSITIONS:', data.positions.length, 'positions');
            
            // Pozisyonları global state'e kaydet (ortalama kaldıraç hesabı için)
            _portfolioData.openPositions = data.positions;
            
            _renderPositionsTicker(data.positions);
            
            // Ortalama kaldıraç hesapla ve güncelle
            _updateAverageLeverage(data.positions);
        } else {
            console.warn('❌ Positions error:', data);
            if (content) {
                content.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);width:100%">Pozisyon verisi alınamadı</div>';
            }
        }
    } catch (e) {
        console.error('❌ Positions load error:', e);
        if (content) {
            content.innerHTML = '<div style="padding:40px;text-align:center;color:#f6465d;width:100%">Hata: ' + e.message + '</div>';
        }
    }
}

// Pozisyonları otomatik yenile (3 saniyede bir)
function startPositionsAutoRefresh() {
    if (_positionsTimer) {
        clearInterval(_positionsTimer);
    }
    
    // İlk yükleme - loading göster
    loadPositions(true);
    
    // 3 saniyede bir yenile - loading gösterme
    _positionsTimer = setInterval(() => {
        loadPositions(false);
    }, 3000);
}

function stopPositionsAutoRefresh() {
    if (_positionsTimer) {
        clearInterval(_positionsTimer);
        _positionsTimer = null;
    }
}

// ─── Update Average Leverage ───
function _updateAverageLeverage(positions) {
    const avgLeverageEl = document.getElementById('pf-avg-leverage');
    const openPositionsCountEl = document.getElementById('pf-open-positions-count');
    
    // Sadece açık pozisyonları filtrele
    const openPositions = positions.filter(p => parseFloat(p.positionAmt || 0) !== 0);
    
    // Açık pozisyon sayısını güncelle
    if (openPositionsCountEl) {
        openPositionsCountEl.textContent = openPositions.length;
    }
    
    if (!avgLeverageEl) return;
    
    if (openPositions.length === 0) {
        avgLeverageEl.textContent = '—';
        avgLeverageEl.style.color = 'rgba(255,255,255,0.4)';
        return;
    }
    
    // Ortalama kaldıraç hesapla
    const totalLeverage = openPositions.reduce((sum, p) => sum + parseInt(p.leverage || 1), 0);
    const avgLeverage = totalLeverage / openPositions.length;
    
    // Göster
    avgLeverageEl.textContent = avgLeverage.toFixed(1) + 'x';
    
    // Renk kodlama: 1-5x yeşil, 6-10x sarı, 10+ kırmızı
    if (avgLeverage <= 5) {
        avgLeverageEl.style.color = '#10b981';
    } else if (avgLeverage <= 10) {
        avgLeverageEl.style.color = '#fbbf24';
    } else {
        avgLeverageEl.style.color = '#ef4444';
    }
    
    console.log(`[AVG LEVERAGE] ${openPositions.length} positions, avg: ${avgLeverage.toFixed(1)}x`);
}

function _renderPositionsTicker(positions) {
    const section = document.getElementById('pf-positions-section');
    const content = document.getElementById('pf-positions-content');
    
    if (!section || !content) return;

    // Sadece açık pozisyonları göster
    const openPositions = positions.filter(p => parseFloat(p.positionAmt || 0) !== 0);

    if (openPositions.length === 0) {
        content.innerHTML = '<div style="padding:40px;text-align:center;color:var(--t3);width:100%">Açık pozisyon yok</div>';
        return;
    }

    // Tablo formatında render et
    content.innerHTML = `
        <table style="width:100%;border-collapse:collapse">
            <thead>
                <tr style="border-bottom:1px solid rgba(255,255,255,0.1)">
                    <th style="padding:16px 20px;text-align:left;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">Symbol</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">Size</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">Entry</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">Last</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">Mark</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">Liq.</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">Margin</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">M.Ratio</th>
                    <th style="padding:16px 20px;text-align:right;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px">PNL(ROI)</th>
                    <th style="padding:16px 20px;text-align:center;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:0.6px"></th>
                </tr>
            </thead>
            <tbody>
                ${openPositions.map(p => {
                    const posAmt = parseFloat(p.positionAmt || 0);
                    const entryPrice = parseFloat(p.entryPrice || 0);
                    const markPrice = parseFloat(p.markPrice || 0);
                    
                    // LAST PRICE - PNL hesabı için (eğer yoksa mark price kullan)
                    const lastPrice = parseFloat(p.lastPrice || 0);
                    const priceForPnl = lastPrice > 0 ? lastPrice : markPrice;
                    
                    const liqPrice = parseFloat(p.liquidationPrice || 0);
                    const leverage = parseInt(p.leverage || 1);
                    const marginType = p.marginType || 'cross';
                    
                    // Position side belirleme
                    const isLong = posAmt > 0;
                    const sideColor = isLong ? '#0ecb81' : '#f6465d';
                    const sideText = isLong ? 'LONG' : 'SHORT';
                    
                    // Debug - hangi fiyatı kullandığımızı görelim
                    if (p.symbol === 'BTCUSDT' || p.symbol === 'ETHUSDT') {
                        console.log(`[PNL DEBUG] ${p.symbol} (${sideText}): lastPrice=${lastPrice}, markPrice=${markPrice}, using=${priceForPnl}`);
                    }
                    
                    // ═══════════════════════════════════════════════════════════
                    // PNL HESAPLAMA - LAST PRICE İLE (Binance Kuralı)
                    // ═══════════════════════════════════════════════════════════
                    let calculatedPnl = 0;
                    if (isLong) {
                        // Long: (Last Price - Entry Price) × Size
                        calculatedPnl = (priceForPnl - entryPrice) * Math.abs(posAmt);
                    } else {
                        // Short: (Entry Price - Last Price) × Size
                        calculatedPnl = (entryPrice - priceForPnl) * Math.abs(posAmt);
                    }
                    
                    const pnlColor = calculatedPnl >= 0 ? '#0ecb81' : '#f6465d';
                    const pnlSign = calculatedPnl > 0 ? '+' : (calculatedPnl < 0 ? '-' : '');
                    
                    // ═══════════════════════════════════════════════════════════
                    // MARGIN HESAPLAMA - BACKEND'DEN GELİYOR
                    // ═══════════════════════════════════════════════════════════
                    let displayMargin = parseFloat(p.initialMargin || 0);
                    
                    // Fallback: Eğer backend'den gelmediyse hesapla
                    if (displayMargin === 0) {
                        if (marginType === 'isolated') {
                            displayMargin = parseFloat(p.isolatedMargin || 0);
                        } else {
                            // Cross margin: (Position Size × Mark Price) / Leverage
                            const positionValue = Math.abs(posAmt) * markPrice;
                            displayMargin = positionValue / leverage;
                        }
                    }
                    
                    // ═══════════════════════════════════════════════════════════
                    // ROI HESAPLAMA: (Last Price PNL / Mark Price Margin) × 100
                    // ═══════════════════════════════════════════════════════════
                    const roi = displayMargin > 0 ? (calculatedPnl / displayMargin * 100) : 0;
                    
                    // ═══════════════════════════════════════════════════════════
                    // MARGIN RATIO - BİNANCE API'DEN DİREKT
                    // ═══════════════════════════════════════════════════════════
                    const marginRatioFromApi = parseFloat(p.marginRatio || 0);
                    const displayMarginRatio = marginRatioFromApi * 100; // Yüzdeye çevir
                    
                    // Debug
                    if (p.symbol === 'BTCUSDT' || p.symbol === 'ETHUSDT') {
                        console.log(`[MARGIN RATIO] ${p.symbol} (${sideText}): ${displayMarginRatio.toFixed(2)}% (API'den)`);
                        console.log(`[MARGIN] ${p.symbol} (${sideText}): ${displayMargin.toFixed(2)} USDT`);
                        console.log(`[MARK PRICE] ${p.symbol} (${sideText}): ${markPrice.toFixed(2)}`);
                        console.log(`[PNL] ${p.symbol} (${sideText}): ${calculatedPnl.toFixed(2)} USDT`);
                        console.log(`[ROI] ${p.symbol} (${sideText}): ${roi.toFixed(2)}%`);
                    }

                    return `
                        <tr style="border-bottom:1px solid rgba(255,255,255,0.03);transition:all 0.3s" 
                            class="position-row"
                            data-symbol="${p.symbol}"
                            data-amount="${posAmt}"
                            data-side="${isLong ? 'Long' : 'Short'}"
                            data-position-side="${(p.positionSide || (isLong ? 'LONG' : 'SHORT'))}">
                            <td style="padding:18px 16px;position:relative">
                                <div style="display:flex;align-items:center;gap:6px">
                                    <span style="font-weight:700;font-size:13px;color:#fff">${p.symbol}</span>
                                    <span style="padding:2px 5px;border-radius:3px;font-size:9px;font-weight:700;background:${isLong ? 'rgba(14,203,129,.15)' : 'rgba(246,70,93,.15)'};color:${sideColor}">${isLong ? 'Long' : 'Short'}</span>
                                    <span style="font-size:10px;color:rgba(255,255,255,0.5)">${leverage}x</span>
                                </div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:600;color:#fff;font-family:var(--mono)">${Math.abs(posAmt).toFixed(3)}</div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:500;color:#fff;font-family:var(--mono)">$${entryPrice.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}</div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:600;color:#fbbf24;font-family:var(--mono)">$${priceForPnl.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}</div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:500;color:#fff;font-family:var(--mono)">$${markPrice.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}</div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:500;color:${liqPrice > 0 ? '#f6465d' : 'rgba(255,255,255,0.5)'};font-family:var(--mono)">${liqPrice > 0 ? '$' + liqPrice.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) : '--'}</div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:600;color:#fff;font-family:var(--mono)">$${displayMargin.toFixed(1)}</div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:500;color:#fff;font-family:var(--mono)">${displayMarginRatio > 0 ? displayMarginRatio.toFixed(2) + '%' : '--'}</div>
                            </td>
                            <td style="padding:12px 16px;text-align:right;position:relative">
                                <div style="font-size:13px;font-weight:700;color:${pnlColor};font-family:var(--mono)">${pnlSign}$${Math.abs(calculatedPnl).toFixed(2)}</div>
                                <div style="font-size:11px;font-weight:600;color:${pnlColor};font-family:var(--mono)">${pnlSign}${Math.abs(roi).toFixed(2)}%</div>
                            </td>
                            <td style="padding:12px 16px;text-align:center;vertical-align:middle">
                                <button type="button" 
                                    class="pf-close-btn" 
                                    data-symbol="${p.symbol}" 
                                    data-amount="${posAmt}" 
                                    data-side="${isLong ? 'Long' : 'Short'}" 
                                    data-position-side="${p.positionSide || (isLong ? 'LONG' : 'SHORT')}">
                                    Kapat
                                </button>
                            </td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
            <tfoot>
                <tr style="border-top:2px solid rgba(255,255,255,0.15);background:${(() => {
                    const totalPnl = openPositions.reduce((sum, p) => {
                        const posAmt = parseFloat(p.positionAmt || 0);
                        const entryPrice = parseFloat(p.entryPrice || 0);
                        const lastPrice = parseFloat(p.lastPrice || 0);
                        const markPrice = parseFloat(p.markPrice || 0);
                        const priceForPnl = lastPrice > 0 ? lastPrice : markPrice;
                        const isLong = posAmt > 0;
                        let pnl = 0;
                        if (isLong) {
                            pnl = (priceForPnl - entryPrice) * Math.abs(posAmt);
                        } else {
                            pnl = (entryPrice - priceForPnl) * Math.abs(posAmt);
                        }
                        return sum + pnl;
                    }, 0);
                    return totalPnl >= 0 ? 'rgba(14,203,129,0.12)' : 'rgba(246,70,93,0.12)';
                })()}">
                    <td colspan="9" style="padding:18px 20px;text-align:right;font-size:14px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:0.8px">
                        Toplam P&L
                    </td>
                    <td style="padding:18px 20px;text-align:right">
                        ${(() => {
                            const totalPnl = openPositions.reduce((sum, p) => {
                                const posAmt = parseFloat(p.positionAmt || 0);
                                const entryPrice = parseFloat(p.entryPrice || 0);
                                const lastPrice = parseFloat(p.lastPrice || 0);
                                const markPrice = parseFloat(p.markPrice || 0);
                                const priceForPnl = lastPrice > 0 ? lastPrice : markPrice;
                                const isLong = posAmt > 0;
                                let pnl = 0;
                                if (isLong) {
                                    pnl = (priceForPnl - entryPrice) * Math.abs(posAmt);
                                } else {
                                    pnl = (entryPrice - priceForPnl) * Math.abs(posAmt);
                                }
                                return sum + pnl;
                            }, 0);
                            const color = totalPnl >= 0 ? '#0ecb81' : '#f6465d';
                            const sign = totalPnl > 0 ? '+' : (totalPnl < 0 ? '-' : '');
                            return `<div style="font-size:16px;font-weight:800;color:${color};font-family:var(--mono)">${sign}${Math.abs(totalPnl).toFixed(2)}</div>`;
                        })()}
                    </td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    `;
}

// ─── Load Open Orders ───
async function loadOpenOrders() {
    if (!AUTH.token) return;

    try {
        const res = await fetch(API + '/binance/orders', {
            headers: { 'Authorization': 'Bearer ' + AUTH.token }
        });
        const data = await res.json();

        if (res.ok) {
            _portfolioData.openOrders = data.orders || [];
            _renderOpenOrders(data.orders || []);
            
            const countEl = document.getElementById('pf-open-count');
            if (countEl) countEl.textContent = (data.orders || []).length;
        }
    } catch (e) {
        console.warn('Open orders load error:', e);
    }
}

function _renderOpenOrders(orders) {
    const tbody = document.getElementById('pf-open-orders-body');
    if (!tbody) return;

    if (orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="padding:40px;text-align:center;color:var(--t3)">Veri yok</td></tr>';
        return;
    }

    tbody.innerHTML = orders.map(o => {
        const isBuy = o.side === 'BUY';
        return `<tr style="border-bottom:1px solid rgba(255,255,255,0.03)">
            <td style="padding:12px 14px;font-weight:600;font-family:var(--mono)">${o.symbol}</td>
            <td style="padding:12px 14px;text-align:center">
                <span style="padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;background:${isBuy ? 'rgba(0,230,118,.15)' : 'rgba(239,83,80,.15)'};color:${isBuy ? 'var(--green)' : 'var(--red)'}">${isBuy ? 'BUY' : 'SELL'}</span>
            </td>
            <td style="padding:12px 14px;text-align:right;font-family:var(--mono);font-size:13px">$${parseFloat(o.price).toLocaleString('en-US', { maximumFractionDigits: 2 })}</td>
            <td style="padding:12px 14px;text-align:right;font-family:var(--mono);font-size:13px">${parseFloat(o.origQty).toFixed(6)}</td>
            <td style="padding:12px 14px;text-align:center">
                <button onclick="window.cancelOrder(${JSON.stringify(o.symbol)}, ${JSON.stringify(String(o.orderId))})" style="background:rgba(239,83,80,.15);border:1px solid rgba(239,83,80,.3);color:var(--red);padding:4px 12px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer">İptal</button>
            </td>
        </tr>`;
    }).join('');
}

async function cancelOrder(symbol, orderId) {
    if (!confirm('Bu emri iptal etmek istediğinizden emin misiniz?')) return;

    try {
        const safeOrderId = String(orderId);
        const res = await fetch(API + `/binance/order/${safeOrderId}?symbol=${encodeURIComponent(symbol)}`, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + AUTH.token }
        });

        const data = await res.json();
        if (res.ok) {
            showToast('success', 'Emir iptal edildi');
            loadOpenOrders();
        } else {
            showToast('error', data.error || 'İptal başarısız');
        }
    } catch (e) {
        showToast('error', 'Bağlantı hatası');
    }
}

window.cancelOrder = cancelOrder;

// ─── Load All Trades ───
async function loadAllTrades() {
    if (!AUTH.token) return;

    const symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT'];
    let allTrades = [];

    try {
        for (const symbol of symbols) {
            try {
                const res = await fetch(API + `/binance/trades?symbol=${symbol}&limit=100`, {
                    headers: { 'Authorization': 'Bearer ' + AUTH.token }
                });
                
                if (res.ok) {
                    const data = await res.json();
                    if (data.trades && data.trades.length > 0) {
                        allTrades = allTrades.concat(data.trades.map(t => ({
                            ...t,
                            isBuyer: t.buyer || t.side === 'BUY'
                        })));
                    }
                }
            } catch (e) {
                console.warn(`Failed to load trades for ${symbol}:`, e);
            }
        }

        // Sort by time descending
        allTrades.sort((a, b) => b.time - a.time);
        
        _portfolioData.allTrades = allTrades;
        _portfolioData.trades = allTrades;
        _portfolioData.reportTrades = allTrades;

        loadTradeHistory();
        filterReportByPeriod(document.getElementById('pf-report-period')?.value || 'all');
        updatePnLChart(allTrades);
        
        console.log(`Loaded ${allTrades.length} trades total`);
        
    } catch (e) {
        console.warn('Trade history load error:', e);
    }
}

function _getTradesByPeriod(trades, period) {
    if (!Array.isArray(trades) || trades.length === 0) {
        return [];
    }

    const now = Date.now();
    let startTime = null;

    switch (period) {
        case 'today':
            startTime = now - (24 * 60 * 60 * 1000);
            break;
        case 'week':
            startTime = now - (7 * 24 * 60 * 60 * 1000);
            break;
        case 'month':
            startTime = now - (30 * 24 * 60 * 60 * 1000);
            break;
        default:
            return trades.slice();
    }

    return trades.filter(t => Number(t.time || 0) >= startTime);
}

function _getTradesBySymbol(trades, symbol) {
    if (!Array.isArray(trades) || trades.length === 0) {
        return [];
    }

    if (!symbol) {
        return trades.slice();
    }

    return trades.filter(t => t.symbol === symbol);
}

function loadTradeHistory() {
    const symbol = document.getElementById('pf-trades-symbol')?.value || '';
    const period = document.getElementById('pf-trades-period')?.value || 'all';
    const baseTrades = Array.isArray(_portfolioData.allTrades) ? _portfolioData.allTrades : [];
    const filteredTrades = _getTradesBySymbol(_getTradesByPeriod(baseTrades, period), symbol);

    _portfolioData.trades = filteredTrades;
    _renderTradeHistory(filteredTrades);

    return filteredTrades;
}

function _renderTradeHistory(trades) {
    const tbody = document.getElementById('pf-trades-body');
    if (!tbody) return;

    if (trades.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="padding:40px;text-align:center;color:var(--t3)">Veri yok</td></tr>';
        
        // Reset commission total
        const commissionEl = document.getElementById('pf-total-commission');
        if (commissionEl) commissionEl.textContent = '$0.00';
        
        return;
    }

    // Calculate total commission
    let totalCommission = 0;
    trades.forEach(t => {
        totalCommission += parseFloat(t.commission || 0);
    });

    tbody.innerHTML = trades.slice(0, 100).map(t => {
        const isBuy = t.isBuyer;
        const date = new Date(t.time);
        const price = parseFloat(t.price);
        const qty = parseFloat(t.qty);
        const total = price * qty;
        const commission = parseFloat(t.commission || 0);

        return `<tr style="border-bottom:1px solid rgba(255,255,255,0.03)">
            <td style="padding:12px 16px;font-size:12px;color:var(--t3);font-family:var(--mono)">${date.toLocaleDateString('tr-TR')} ${date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}</td>
            <td style="padding:12px 16px;font-weight:600;font-family:var(--mono)">${t.symbol}</td>
            <td style="padding:12px 16px;text-align:center">
                <span style="padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;background:${isBuy ? 'rgba(0,230,118,.15)' : 'rgba(239,83,80,.15)'};color:${isBuy ? 'var(--green)' : 'var(--red)'}">${isBuy ? 'BUY' : 'SELL'}</span>
            </td>
            <td style="padding:12px 16px;text-align:right;font-family:var(--mono);font-size:13px">$${price.toLocaleString('en-US', { maximumFractionDigits: 2 })}</td>
            <td style="padding:12px 16px;text-align:right;font-family:var(--mono);font-size:13px">${qty.toFixed(6)}</td>
            <td style="padding:12px 16px;text-align:right;font-family:var(--mono);font-size:13px;font-weight:600">$${total.toLocaleString('en-US', { maximumFractionDigits: 2 })}</td>
            <td style="padding:12px 16px;text-align:right;font-family:var(--mono);font-size:12px;color:var(--t3)">$${commission.toFixed(4)}</td>
        </tr>`;
    }).join('');
    
    // Update total commission display (2 decimal places)
    const commissionEl = document.getElementById('pf-total-commission');
    if (commissionEl) {
        commissionEl.textContent = '$' + totalCommission.toFixed(2);
    }
}

// ─── Calculate Statistics ───
function _calculateStatistics(sourceTrades = null) {
    const trades = Array.isArray(sourceTrades) ? sourceTrades : _portfolioData.reportTrades;
    
    if (trades.length === 0) {
        _setDefaultStats();
        return;
    }

    try {
        // Calculate P&L from realizedPnl field
        let totalPnL = 0;
        let totalVolume = 0;
        let totalCommission = 0;
        let wins = 0;
        let losses = 0;
        let breakeven = 0;
        let totalWinAmount = 0;
        let totalLossAmount = 0;
        let maxWin = 0;
        let maxLoss = 0;

        const now = Date.now();
        const dayAgo = now - 24 * 60 * 60 * 1000;
        const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
        const monthAgo = now - 30 * 24 * 60 * 60 * 1000;

        let dailyPnL = 0, weeklyPnL = 0, monthlyPnL = 0;
        let dailyTrades = 0, dailyVolume = 0;
        
        // Maximum Drawdown hesaplama için
        let peak = 0;
        let maxDrawdown = 0;
        let runningBalance = 5000; // Başlangıç sermayesi

        trades.forEach(t => {
            const price = parseFloat(t.price);
            const qty = parseFloat(t.qty);
            const total = price * qty;
            const pnl = parseFloat(t.realizedPnl || 0);
            const commission = parseFloat(t.commission || 0);
            
            totalVolume += total;
            totalCommission += commission;
            totalPnL += pnl;
            
            // Running balance güncelle
            runningBalance += pnl;
            
            // Peak güncelle
            if (runningBalance > peak) {
                peak = runningBalance;
            }
            
            // Drawdown hesapla
            const drawdown = peak > 0 ? ((peak - runningBalance) / peak) * 100 : 0;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
            }
            
            // Başa baş kontrolü (±$0.01 tolerans)
            if (Math.abs(pnl) < 0.01) {
                breakeven++;
            } else if (pnl > 0) {
                wins++;
                totalWinAmount += pnl;
                if (pnl > maxWin) maxWin = pnl;
            } else {
                losses++;
                totalLossAmount += Math.abs(pnl);
                if (Math.abs(pnl) > maxLoss) maxLoss = Math.abs(pnl);
            }

            if (t.time >= dayAgo) {
                dailyTrades++;
                dailyVolume += total;
                dailyPnL += pnl;
            }
            if (t.time >= weekAgo) {
                weeklyPnL += pnl;
            }
            if (t.time >= monthAgo) {
                monthlyPnL += pnl;
            }
        });

        // Update portfolio data
        _portfolioData.totalPnL = totalPnL;
        _portfolioData.dailyPnL = dailyPnL;
        _portfolioData.weeklyPnL = weeklyPnL;
        _portfolioData.monthlyPnL = monthlyPnL;

        const winRate = wins + losses > 0 ? (wins / (wins + losses) * 100) : 0;
        const profitFactor = totalLossAmount > 0 ? (totalWinAmount / totalLossAmount) : (totalWinAmount > 0 ? 999 : 0);
        const avgWin = wins > 0 ? (totalWinAmount / wins) : 0;
        const avgLoss = losses > 0 ? (totalLossAmount / losses) : 0;
        const riskReward = avgLoss > 0 ? (avgWin / avgLoss) : (avgWin > 0 ? 999 : 0);
        const netPnlTotal = totalPnL - totalCommission;

        // Update P&L cards with correct colors
        const dailyPnlEl = document.getElementById('pf-daily-pnl');
        if (dailyPnlEl) {
            dailyPnlEl.textContent = _formatPnL(dailyPnL);
            dailyPnlEl.style.color = dailyPnL >= 0 ? '#0ecb81' : '#f6465d';
        }
        
        const weeklyPnlEl = document.getElementById('pf-weekly-pnl');
        if (weeklyPnlEl) {
            weeklyPnlEl.textContent = _formatPnL(weeklyPnL);
            weeklyPnlEl.style.color = weeklyPnL >= 0 ? '#0ecb81' : '#f6465d';
        }
        
        const monthlyPnlEl = document.getElementById('pf-monthly-pnl');
        if (monthlyPnlEl) {
            monthlyPnlEl.textContent = _formatPnL(monthlyPnL);
            monthlyPnlEl.style.color = monthlyPnL >= 0 ? '#0ecb81' : '#f6465d';
        }
        
        // Update mini charts
        if (typeof updatePnlCharts === 'function') {
            updatePnlCharts(dailyPnL, weeklyPnL, monthlyPnL);
        }

        // Performans Raporu - Kapsamlı
        const totalTradesEl = document.getElementById('pf-total-trades');
        const totalWinsEl = document.getElementById('pf-total-wins');
        const totalLossesEl = document.getElementById('pf-total-losses');
        const totalBreakevenEl = document.getElementById('pf-total-breakeven');
        const winRateEl = document.getElementById('pf-win-rate');
        const profitFactorEl = document.getElementById('pf-profit-factor');
        const avgWinEl = document.getElementById('pf-avg-win');
        const avgLossEl = document.getElementById('pf-avg-loss');
        const riskRewardEl = document.getElementById('pf-risk-reward');
        const maxWinEl = document.getElementById('pf-max-win');
        const maxLossEl = document.getElementById('pf-max-loss');
        const maxDrawdownEl = document.getElementById('pf-max-drawdown');
        const totalVolumeEl = document.getElementById('pf-total-volume');
        const totalCommissionReportEl = document.getElementById('pf-total-commission-report');
        const netPnlTotalEl = document.getElementById('pf-net-pnl-total');
        const dailyVolumeEl = document.getElementById('pf-daily-volume');
        
        if (totalTradesEl) totalTradesEl.textContent = trades.length;
        if (totalWinsEl) totalWinsEl.textContent = wins;
        if (totalLossesEl) totalLossesEl.textContent = losses;
        if (totalBreakevenEl) totalBreakevenEl.textContent = breakeven;
        
        if (winRateEl) {
            winRateEl.textContent = winRate.toFixed(1) + '%';
            // Sadece metin rengi değişsin
            winRateEl.style.color = winRate >= 50 ? '#10b981' : '#ef4444';
        }
        
        if (profitFactorEl) {
            profitFactorEl.textContent = profitFactor >= 999 ? '∞' : profitFactor.toFixed(2);
            // Sadece metin rengi değişsin
            profitFactorEl.style.color = profitFactor >= 2 ? '#10b981' : (profitFactor >= 1 ? '#fbbf24' : '#ef4444');
        }
        
        if (avgWinEl) avgWinEl.textContent = '+$' + avgWin.toFixed(2);
        if (avgLossEl) avgLossEl.textContent = '-$' + avgLoss.toFixed(2);
        
        if (riskRewardEl) {
            riskRewardEl.textContent = riskReward >= 999 ? '∞' : riskReward.toFixed(2);
            riskRewardEl.style.color = riskReward >= 1.5 ? '#10b981' : (riskReward >= 1 ? '#fbbf24' : '#ef4444');
        }
        
        if (maxWinEl) maxWinEl.textContent = '+$' + maxWin.toFixed(2);
        if (maxLossEl) maxLossEl.textContent = '-$' + maxLoss.toFixed(2);
        
        if (maxDrawdownEl) {
            maxDrawdownEl.textContent = maxDrawdown.toFixed(2) + '%';
            // Sadece metin rengi değişsin
            maxDrawdownEl.style.color = maxDrawdown < 10 ? '#10b981' : (maxDrawdown < 20 ? '#fbbf24' : '#ef4444');
        }
        
        if (totalVolumeEl) totalVolumeEl.textContent = '$' + totalVolume.toLocaleString('en-US', { maximumFractionDigits: 0 });
        if (totalCommissionReportEl) totalCommissionReportEl.textContent = '$' + totalCommission.toFixed(2);
        
        if (netPnlTotalEl) {
            netPnlTotalEl.textContent = _formatPnL(netPnlTotal);
            // Sadece metin rengi değişsin, arka plan sabit
            netPnlTotalEl.style.color = netPnlTotal >= 0 ? '#10b981' : '#ef4444';
        }
        
        // Günlük metrikler
        if (dailyVolumeEl) dailyVolumeEl.textContent = '$' + dailyVolume.toLocaleString('en-US', { maximumFractionDigits: 0 });
        
        // Toplam P&L (en alttaki kart)
        const totalPnlBottomEl = document.getElementById('pf-total-pnl-bottom');
        if (totalPnlBottomEl) {
            totalPnlBottomEl.textContent = _formatPnL(totalPnL);
            // Sadece metin rengi değişsin
            totalPnlBottomEl.style.color = totalPnL >= 0 ? '#10b981' : '#ef4444';
        }
        
    } catch (error) {
        console.error('Error in _calculateStatistics:', error);
    }
}

// Tarih filtresi fonksiyonu
function filterReportByPeriod(period) {
    console.log('Filtering report by period:', period);
    const baseTrades = Array.isArray(_portfolioData.allTrades) ? _portfolioData.allTrades : [];
    const filteredTrades = _getTradesByPeriod(baseTrades, period || 'all');

    _portfolioData.reportTrades = filteredTrades;
    _calculateStatistics(filteredTrades);

    return filteredTrades;
}

function _setDefaultStats() {
    const zeros = ['pf-daily-pnl', 'pf-weekly-pnl', 'pf-monthly-pnl'];
    zeros.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.textContent = '—';
            el.style.color = 'rgba(255,255,255,0.4)';
        }
    });
    
    const numZeros = ['pf-daily-volume', 'pf-avg-leverage', 'pf-open-positions-count',
                      'pf-total-trades', 'pf-total-wins', 'pf-total-losses', 'pf-total-breakeven', 
                      'pf-win-rate', 'pf-profit-factor', 'pf-avg-win', 'pf-avg-loss', 
                      'pf-risk-reward', 'pf-max-win', 'pf-max-loss', 'pf-max-drawdown',
                      'pf-total-volume', 'pf-total-commission-report', 'pf-net-pnl-total', 'pf-total-pnl-bottom'];
    numZeros.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = '—';
    });
}

function _formatPnL(value) {
    const sign = value > 0 ? '+' : (value < 0 ? '-' : '');
    return sign + '$' + Math.abs(value).toLocaleString('en-US', { maximumFractionDigits: 2 });
}

// ─── PnL Chart ───
function updatePnLChart(trades) {
    const chartContainer = document.getElementById('pf-pnl-chart');
    if (!chartContainer) return;

    if (!_pnlChart) {
        _pnlChart = LightweightCharts.createChart(chartContainer, {
            layout: { 
                background: { type: 'solid', color: 'transparent' }, 
                textColor: 'rgba(255, 255, 255, 0.5)' 
            },
            grid: { 
                vertLines: { color: 'rgba(255, 255, 255, 0.05)' }, 
                horzLines: { color: 'rgba(255, 255, 255, 0.05)' } 
            },
            timeScale: { 
                timeVisible: true,
                secondsVisible: false,
                borderColor: 'rgba(255,255,255,0.1)' 
            },
            rightPriceScale: { 
                borderColor: 'rgba(255,255,255,0.1)' 
            }
        });
        
        _pnlSeries = _pnlChart.addAreaSeries({
            topColor: 'rgba(0, 230, 118, 0.4)',
            bottomColor: 'rgba(0, 230, 118, 0.0)',
            lineColor: 'rgba(0, 230, 118, 1)',
            lineWidth: 2,
        });
        
        new ResizeObserver(entries => {
            if (entries.length === 0 || entries[0].target !== chartContainer) return;
            const newRect = entries[0].contentRect;
            _pnlChart.applyOptions({ height: newRect.height, width: newRect.width });
        }).observe(chartContainer);
    }
    
    // Sort trades ascending by time
    const sortedTrades = [...trades].sort((a, b) => a.time - b.time);
    
    let cumulative = 0;
    const chartData = [];
    
    if (sortedTrades.length === 0) {
        chartData.push({ time: Math.floor(Date.now() / 1000) - 86400, value: 0 });
        chartData.push({ time: Math.floor(Date.now() / 1000), value: 0 });
    } else {
        sortedTrades.forEach(t => {
            cumulative += parseFloat(t.realizedPnl || 0);
            chartData.push({
                time: Math.floor(t.time / 1000),
                value: cumulative
            });
        });
    }

    const uniqueData = [];
    chartData.forEach(d => {
        if (uniqueData.length > 0 && uniqueData[uniqueData.length - 1].time === d.time) {
            uniqueData[uniqueData.length - 1].value = d.value;
        } else {
            uniqueData.push(d);
        }
    });

    _pnlSeries.setData(uniqueData);
    
    if (cumulative < 0) {
        _pnlSeries.applyOptions({
            topColor: 'rgba(239, 83, 80, 0.4)',
            bottomColor: 'rgba(239, 83, 80, 0.0)',
            lineColor: 'rgba(239, 83, 80, 1)',
        });
    } else {
        _pnlSeries.applyOptions({
            topColor: 'rgba(0, 230, 118, 0.4)',
            bottomColor: 'rgba(0, 230, 118, 0.0)',
            lineColor: 'rgba(0, 230, 118, 1)',
        });
    }
    
    try {
        _pnlChart.timeScale().fitContent();
    } catch(e){}
}

// ─── API Status Helpers ───
function _setApiConnected(connected) {
    const iconEl = document.getElementById('pf-api-status-icon');
    if (iconEl) {
        iconEl.textContent = connected ? '🟢' : '🔴';
        iconEl.style.textShadow = connected ? '0 0 10px rgba(16,185,129,0.5)' : '0 0 10px rgba(239,68,68,0.5)';
        iconEl.style.filter = 'none';
        iconEl.title = connected ? 'API Bağlı' : 'API Bağlantısı Yok';
    }
}

function _setApiNotConfigured() {
    const iconEl = document.getElementById('pf-api-status-icon');
    if (iconEl) {
        iconEl.textContent = '🔴';
        iconEl.style.textShadow = '0 0 10px rgba(239,68,68,0.5)';
        iconEl.style.filter = 'none';
        iconEl.title = 'API Yapılandırılmamış';
    }
    
    const listEl = document.getElementById('pf-assets-list');
    const tbody3 = document.getElementById('pf-trades-body');
    
    const msg = 'API anahtarları yapılandırılmamış. Lütfen API Ayarları bölümünden anahtarlarınızı ekleyin.';
    if (listEl) listEl.innerHTML = '<div style="padding:40px;text-align:center;color:rgba(255,255,255,0.3)">' + msg + '</div>';
    if (tbody3) tbody3.innerHTML = '<tr><td colspan="10" style="padding:40px;text-align:center;color:var(--t3)">' + msg + '</td></tr>';
    
    _setDefaultStats();
}

function _setApiError(error) {
    const iconEl = document.getElementById('pf-api-status-icon');
    if (iconEl) {
        iconEl.textContent = '🔴';
        iconEl.style.textShadow = '0 0 10px rgba(239,68,68,0.5)';
        iconEl.style.filter = 'none';
        iconEl.title = 'API Hatası: ' + error;
    }
    console.error('API Error:', error);
}

// ─── Portfolio Particles Animation ───
(function initPortfolioParticles() {
    const canvas = document.getElementById('portfolio-particle-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const container = document.getElementById('dash-portfolio');
    let W, H, particles = [];

    function resize() {
        W = container.offsetWidth || window.innerWidth;
        H = container.offsetHeight || window.innerHeight;
        canvas.width = W;
        canvas.height = H;
    }

    resize();
    window.addEventListener('resize', resize);

    // Create particles
    for (let i = 0; i < 40; i++) {
        particles.push({
            x: Math.random() * W,
            y: Math.random() * H,
            vx: (Math.random() - 0.5) * 0.3,
            vy: (Math.random() - 0.5) * 0.3,
            r: Math.random() * 1.5 + 0.5,
            a: Math.random() * 0.2 + 0.05
        });
    }

    function draw() {
        // Only draw if portfolio page is visible
        if (container.style.display === 'none') {
            requestAnimationFrame(draw);
            return;
        }

        ctx.clearRect(0, 0, W, H);

        particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;
            if (p.x < 0) p.x = W;
            if (p.x > W) p.x = 0;
            if (p.y < 0) p.y = H;
            if (p.y > H) p.y = 0;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255,255,255,${p.a})`;
            ctx.fill();
        });

        // Draw connections
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < 120) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.strokeStyle = `rgba(255,255,255,${0.04 * (1 - d / 120)})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(draw);
    }
    draw();
})();


// closePosition, showClosePositionModal, confirmClosePosition → close-position-modal.js
window.loadTradeHistory = loadTradeHistory;
window.filterReportByPeriod = filterReportByPeriod;
