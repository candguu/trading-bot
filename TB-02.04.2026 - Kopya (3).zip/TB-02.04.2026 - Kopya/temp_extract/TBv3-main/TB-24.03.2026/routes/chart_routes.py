"""
TB Trading Bot — Chart & OTT Indicator Routes
Binance Futures public API'den OHLCV çeker, OTT hesaplar, JSON döner.
"""
import time
import math
import threading
import requests
from flask import Blueprint, jsonify, request

chart_bp = Blueprint("chart", __name__)

BINANCE_BASE = "https://fapi.binance.com"  # Futures (public, auth gerekmez)
BINANCE_SPOT = "https://api.binance.com"

_cache: dict = {}
_cache_lock = threading.Lock()
CACHE_TTL = 30  # saniye

INTERVAL_MAP = {
    "1m": 100, "3m": 100, "5m": 100, "15m": 100,
    "30m": 100, "1h": 100, "4h": 100, "1d": 100,
}

BINANCE_MAX_PER_REQ = 1000   # Binance API per-request hard limit
CACHE_TTL = 60               # büyük veri seti için 60s cache

# ── Binance OHLCV (paginated, max 10 000 mum) ─────────────────────────────────
def fetch_klines(symbol: str, interval: str, limit: int = 500) -> list | None:
    limit = min(limit, 10_000)
    cache_key = f"{symbol}_{interval}_{limit}"
    now = time.time()
    with _cache_lock:
        if cache_key in _cache:
            data, ts = _cache[cache_key]
            if now - ts < CACHE_TTL:
                return data

    all_candles: list = []
    end_time: int | None = None          # ms timestamp, geriye doğru gidiyoruz

    # Futures URL yok, Spot'a doğrudan başla; ama önce Futures dene
    for base in [BINANCE_BASE, BINANCE_SPOT]:
        all_candles = []
        end_time    = None
        success     = True

        remaining = limit
        while remaining > 0:
            batch = min(remaining, BINANCE_MAX_PER_REQ)
            url   = (f"{base}/fapi/v1/klines" if "fapi" in base
                     else f"{base}/api/v3/klines")
            params: dict = {"symbol": symbol, "interval": interval, "limit": batch}
            if end_time:
                params["endTime"] = end_time - 1   # bir önceki mumdan öncesi

            try:
                r = requests.get(url, params=params, timeout=8)
                if r.status_code != 200:
                    success = False
                    break
                raw = r.json()
                if not raw:
                    break   # daha fazla veri yok
                chunk = [
                    {"t": int(c[0]), "o": float(c[1]), "h": float(c[2]),
                     "l": float(c[3]), "c": float(c[4]), "v": float(c[5])}
                    for c in raw
                ]
                all_candles = chunk + all_candles   # başa ekle (kronolojik sıra)
                end_time    = int(raw[0][0])        # en eski mumun açılış zamanı
                remaining  -= len(chunk)
                if len(chunk) < batch:
                    break   # Binance'de daha fazla veri yok
            except Exception as e:
                print(f"[CHART] Kline fetch hata ({base}): {e}")
                success = False
                break

        if success and all_candles:
            with _cache_lock:
                _cache[cache_key] = (all_candles, now)
            return all_candles

    return None if not all_candles else all_candles

# ── OTT Hesaplama (Pine Script portuna birebir eşdeğer) ──────────────────────
def calc_var(closes: list, length: int) -> list:
    """Volatility Adjusted Ratio MA (VAR) — OTT'nin default MA'sı"""
    alpha = 2 / (length + 1)
    n = len(closes)
    var = [0.0] * n

    # 9 periyotluk UD/DD için yeterli geçmiş lazım
    for i in range(n):
        if i == 0:
            var[i] = closes[i]
            continue
        ud = max(closes[i] - closes[i-1], 0)
        dd = max(closes[i-1] - closes[i], 0)
        # sum over last 9
        start = max(0, i - 8)
        ud_sum = sum(max(closes[j] - closes[j-1], 0) for j in range(start+1, i+1))
        dd_sum = sum(max(closes[j-1] - closes[j], 0) for j in range(start+1, i+1))
        denom = ud_sum + dd_sum
        cmo = (ud_sum - dd_sum) / denom if denom != 0 else 0
        var[i] = alpha * abs(cmo) * closes[i] + (1 - alpha * abs(cmo)) * var[i-1]
    return var

def calc_ott(closes: list, length: int = 2, percent: float = 1.4) -> dict:
    """
    OTT (Optimized Trend Tracker) hesapla.
    Döner: {mavg, ott, dir, buy_signals, sell_signals}
    """
    n = len(closes)
    mavg = calc_var(closes, length)

    fark = [m * percent * 0.01 for m in mavg]

    long_stop  = [0.0] * n
    short_stop = [0.0] * n
    direction  = [1]   * n
    mt         = [0.0] * n
    ott        = [0.0] * n

    for i in range(n):
        ls = mavg[i] - fark[i]
        ss = mavg[i] + fark[i]

        if i == 0:
            long_stop[i]  = ls
            short_stop[i] = ss
        else:
            long_stop[i]  = max(ls, long_stop[i-1])  if mavg[i] > long_stop[i-1]  else ls
            short_stop[i] = min(ss, short_stop[i-1]) if mavg[i] < short_stop[i-1] else ss
            d_prev = direction[i-1]
            if d_prev == -1 and mavg[i] > short_stop[i-1]:
                direction[i] = 1
            elif d_prev == 1 and mavg[i] < long_stop[i-1]:
                direction[i] = -1
            else:
                direction[i] = d_prev

        mt[i]  = long_stop[i] if direction[i] == 1 else short_stop[i]
        ott[i] = mt[i] * (200 + percent) / 200 if mavg[i] > mt[i] else mt[i] * (200 - percent) / 200

    # Sinyaller: OTT[i-1] vs OTT[i-2] (Pine'daki OTT[2] OTT[3] gibi offset 2)
    buy_signals  = []
    sell_signals = []
    for i in range(3, n):
        prev_ott  = ott[i-1]
        prev_ott2 = ott[i-2]
        if prev_ott > prev_ott2 and ott[i-2] <= ott[i-3]:
            buy_signals.append(i)
        if prev_ott < prev_ott2 and ott[i-2] >= ott[i-3]:
            sell_signals.append(i)

    # MAVg crossover OTT sinyalleri (daha duyarlı)
    k_buys  = []
    k_sells = []
    for i in range(2, n):
        if mavg[i-1] > ott[i-1] and mavg[i-2] <= ott[i-2]:
            k_buys.append(i-1)
        if mavg[i-1] < ott[i-1] and mavg[i-2] >= ott[i-2]:
            k_sells.append(i-1)

    return {
        "mavg": mavg,
        "ott":  ott,
        "dir":  direction,
        "buy_signals":  buy_signals,
        "sell_signals": sell_signals,
        "k_buys":  k_buys,
        "k_sells": k_sells,
    }

# ── API Endpoint ─────────────────────────────────────────────────────────────
@chart_bp.route("/ohlcv", methods=["GET"])
def ohlcv():
    symbol   = request.args.get("symbol",   "BTCUSDT").upper()
    interval = request.args.get("interval", "1h")
    ott_len  = int(request.args.get("ott_length",  2))
    ott_pct  = float(request.args.get("ott_percent", 1.4))

    candles = fetch_klines(symbol, interval, limit=10_000)
    if not candles:
        return jsonify({"error": "Veri alınamadı"}), 503

    closes = [c["c"] for c in candles]
    ott_data = calc_ott(closes, length=ott_len, percent=ott_pct)

    # Son sinyal (en yakın)
    last_signal = None
    all_sigs = (
        [{"i": i, "type": "BUY",  "src": "ott"}  for i in ott_data["buy_signals"]] +
        [{"i": i, "type": "SELL", "src": "ott"}  for i in ott_data["sell_signals"]] +
        [{"i": i, "type": "BUY",  "src": "cross"} for i in ott_data["k_buys"]] +
        [{"i": i, "type": "SELL", "src": "cross"} for i in ott_data["k_sells"]]
    )
    if all_sigs:
        last = max(all_sigs, key=lambda x: x["i"])
        last_signal = {
            "type":  last["type"],
            "src":   last["src"],
            "price": candles[last["i"]]["c"],
            "time":  candles[last["i"]]["t"],
        }

    return jsonify({
        "symbol":   symbol,
        "interval": interval,
        "candles":  candles,
        "ott": {
            "mavg": ott_data["mavg"],
            "ott":  ott_data["ott"],
            "dir":  ott_data["dir"],
            "buy_signals":  ott_data["buy_signals"],
            "sell_signals": ott_data["sell_signals"],
            "k_buys":  ott_data["k_buys"],
            "k_sells": ott_data["k_sells"],
        },
        "last_signal": last_signal,
        "current_price": closes[-1],
        "current_dir": ott_data["dir"][-1],
    })
