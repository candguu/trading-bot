import time
import threading
import sqlite3
from datetime import datetime
import os
import random

# We need the path to database
DB_PATH = os.getenv("DB_PATH", os.path.join(os.path.dirname(os.path.dirname(__file__)), "tb_database.db"))

class TradingBotDaemon:
    def __init__(self):
        self.running = False
        self.thread = None
        
        # Keep track of last signal times so we don't spam
        self.last_signals = {}

    def get_db_connection(self):
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
        
    def start(self):
        if self.running: return
        self.running = True
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        print("[BOT] Daemon started in background.")

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join(timeout=2)
        print("[BOT] Daemon stopped.")

    def _get_active_configs(self):
        conn = self.get_db_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM bot_configs WHERE is_active = 1")
        configs = c.fetchall()
        conn.close()
        return configs

    def _log_trade(self, user_id, symbol, signal, price, source):
        conn = self.get_db_connection()
        c = conn.cursor()
        now = datetime.now().isoformat()
        c.execute("""
            INSERT INTO bot_logs (user_id, symbol, signal, price, source, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, symbol, signal, price, source, now))
        conn.commit()
        conn.close()

    def _simulate_market_data_and_check_signals(self, config):
        """
        In a real scenario, this would fetch candles via Binance API, calculate OTT, 
        and determine if there's a crossover.
        For this implementation, we will mock occasional signals for active config.
        """
        user_id = config["user_id"]
        # Basic mock logic for generating random signals every few iterations if active
        
        if random.random() < 0.05:  # 5% chance per tick to generate a signal for demo
            signal = "BUY" if random.random() > 0.5 else "SELL"
            price = 65000 + (random.random() * 5000)
            symbol = "BTCUSDT"
            
            # Simple debounce per user per symbol
            last_time = self.last_signals.get(f"{user_id}_{symbol}")
            current_time = time.time()
            if not last_time or (current_time - last_time > 60):  # At least 60 seconds between signals
                self.last_signals[f"{user_id}_{symbol}"] = current_time
                print(f"[BOT] Generated {signal} signal for user {user_id} on {symbol} at {price}")
                
                # Log to DB
                self._log_trade(user_id, symbol, signal, price, "OTT_Algo_Trigger")
                
                # In real app: call binance_api to place order using the user's encrypted API keys.
                # from core.binance_api import place_order ...
                
    def _run_loop(self):
        while self.running:
            try:
                configs = self._get_active_configs()
                for config in configs:
                    self._simulate_market_data_and_check_signals(config)
            except Exception as e:
                print(f"[BOT] Loop error: {e}")
                
            time.sleep(5)  # Tick every 5 seconds

# Global instance
bot_daemon = TradingBotDaemon()
