import requests

response = requests.post("http://localhost:5000/api/auth/login", json={
    "email": "npcan3@gmail.com",
    "password": "12345678"
})

print(f"Status: {response.status_code}")
if response.status_code == 200:
    print("✅ GİRİŞ BAŞARILI!")
    print(f"Token alındı: {response.json()['token'][:30]}...")
else:
    print("❌ GİRİŞ BAŞARISIZ!")
    print(f"Hata: {response.json()}")
